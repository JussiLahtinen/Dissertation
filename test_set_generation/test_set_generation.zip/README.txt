
Testgen4FBD has the following dependencies:
	*NuSMV 2.5.4
	*Python 2.7
	
The model files used need to annotated to indicate input sections, function block declarations, and the output section.
See the examples to get an idea.

The tool can be with the command "python testgen4FBD FBCs.txt examples\example1.smv".
Running the command will generate a log directory that contains a log of what was done, the generated tests
in text format and the test traces in NuSMV's XML format for counter-examples.
For more tool options run "python testget4FBD.py -h".
	
The used test coverage criterion is hardcoded in the python file. 
See the note on line 1402 of the python file.

The examples directory contains example files that the script 
has been tested on. All the examples are run (using the test coverage
criterion set on the python file by running run.bat.

The file FBCs.txt contains manually calculated function block conditions (FBCs) of function 
blocks in a rather cryptic format. This file need to be given as parameter to testget4FBD in order to 
analyse the example files.

There is a known bug in the code: data paths with directory names containing white space are not supported..




