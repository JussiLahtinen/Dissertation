# coding=latin1
# Updated: 8.5.14 - Jussi Lahtinen

import argparse
import shutil
import datetime
import os
import subprocess
import time
import sys
import re

# Run command, e.g.: 
#	testgen4FBD.py	esim1conditions.txt esim1.smv

# What the program does:
# 	- reads the file (1. parameter) having the function block related information (information on FB inputs, outputs, and function block conditions)
# 	- reads the SMV-model file that is annotated. Determines the function block diagram structure based on the model. 
#	- Adds 'branching' function blocks whenever some variable is goes from a single source to multiple receiving ends. The end result is that all edges of the function block diagram are point-to-point.
# 	- Automatically removes possible loops in the FBD. Replaces loop inducing edge with two edges:A stump output edge leading nowhere (None), and adds a new input instead of the loop-inducing edge.
# 	- Determines the data paths in a DFS manner starting from the inputs
#	- creates data path conditions
# 	- creates test requirements based on the selected test criterion (BCC, ICC, CCC)
# 	- automatically generates test cases that fulfill the test requirements.


# A simple class for storing an input / output assignment part of a test case
# Three fields: variable, state (time point) and value
class TestItem:
	def __init__(self, variable, state, value):
		self.variable = variable
		self.state = state
		self.value = value
	def getValue(self):
		return self.value
	def matches(self, variable, state):
		if ((self.variable == variable) & (self.state == state)):
			return True
		return False

# A class for test cases.
class Test:
	def __init__(self, inputs, outputs):
		self.inputedges = inputs	# a list of input edges, type Edge, received from the FBD 
		self.outputedges = outputs # a list of output edges, type Edge
		self.testlength = 0
		self.testinputdeclarations = [] # a list of input typeTestItems that the test has
		self.testoutputdeclarations = [] # a list of output typeTestItems that the test has
	# create a new TestItem to the test. type=output.
	def addOutputValue(self, var, state, value):
		if state > self.testlength:	# update testlength when necessary
			self.testlength = state
		temp = TestItem(var, state, value)
		self.testoutputdeclarations.append(temp)
	# create a new TestItem to the test. type=input
	def addInputValue(self, var, state, value):
		if state > self.testlength: # update testlength when necessary
			self.testlength = state
		temp = TestItem(var, state, value)
		self.testinputdeclarations.append(temp)
	# return a list of lines (string) that should be printed to an Excel table 
	def getPrintLines(self):
		lines = []
		lines.append('-------------------------------------\n')
		for i in self.inputedges:
			templine =  "Input: \t"+ i.getName()+"\t"
			for state in range(1, self.testlength +1):
				match = False
				for item in self.testinputdeclarations:
					if item.matches(i.getName(), state):
						templine = templine +  item.getValue()+ "\t"
						match = True
						break
				if not match:
					templine = templine +  "---"+ "\t"
			lines.append(templine)
		for i in self.outputedges:
			templine =  "Output: \t"+ i.getOutputName()+"\t"
			for state in range(1, self.testlength +1):
				match = False
				for item in self.testoutputdeclarations:
					if item.matches(i.getName(), state):
						templine = templine +  item.getValue()+ "\t"
						match = True
						break
				if not match:
					templine = templine +  "---"+ "\t"
			lines.append(templine)
		return lines
	# print the test
	def printTest(self):
		print '-------------------------------------'
		for i in self.inputedges:
			print " Input: ", i.getName(), '\t',
			for state in range(1, self.testlength +1):
				match = False
				for item in self.testinputdeclarations:
					if item.matches(i.getName(), state):
						print item.getValue(), '\t',
						match = True
						break
				if not match:
					print '---', '\t',
			print
		for i in self.outputedges:
			print " Output: ", i.getOutputName(), '\t',
			for state in range(1, self.testlength +1):
				match = False
				for item in self.testoutputdeclarations:
					if item.matches(i.getName(), state):
						print item.getValue(), '\t',
						match = True
						break
				if not match:
					print '---', '\t',
			print
		print '-------------------------------------'

# Class for storing temp file names and saving results and information on how the test generation process goes.
class Stats:
	def __init__(self, logdir):
		self.testrequirements = []
		self.testfeasible = []
		self.logdir = logdir
		self.tempdir = os.path.join(logdir, "temp")	# a temporary directory that is created inside the logdirectory to perform model checking in
		self.logname = "general_log.txt"
		self.tempmodel = "temp.smv"
		self.cmdfile = "cmdfile.txt"
		self.tracefile = "trace.txt"
		self.NuSMVoutputfile = "result.txt"
		self.temptrace = os.path.join(self.tempdir, "temptrace.txt")
		self.procedure = []
		self.currentspecnro = 0
		os.makedirs(self.logdir)
		os.chmod(self.logdir, 0o666)
		os.makedirs(self.tempdir)
		os.chmod(self.tempdir, 0o666)
		self.conditions = []	# the test requirements
		self.mapping = {}  #mapping from the test cases to the test requirements that it fulfills
		self.modelcheckingruns = 0 # how many times the model checker is run during the program
		self.totaltime = 0
		self.infeasibles = 0
	def addTestMapping(self, testmapping):
		self.mapping = testmapping
	def modelCheckingRun(self):
		self.modelcheckingruns = self.modelcheckingruns + 1
	def getModelCheckingRuns(self):
		return self.modelcheckingruns
	def newTest(self):
		self.currentspecnro = self.currentspecnro +1
	def getSpecNro(self):
		return self.currentspecnro
	def getTempModelFilename(self):
		f = os.path.join(self.tempdir, self.tempmodel)
		return f
	def addAction(self, string): # Add a string that is added to the log 
		self.procedure.append(string)
	def addInfeasible(self):
		self.infeasibles = self.infeasibles + 1
	def getCMDfile(self):
		f = os.path.join(self.tempdir, self.cmdfile)
		return f
	def getTracefile(self):
		f = os.path.join(self.tempdir, self.tracefile)
		return f
	def getTestTableName(self):
		testname = "Generated_tests.txt"
		tn = os.path.join(self.logdir, testname)
		return tn
	def setTime(self, dd):
		self.totaltime = datetime.datetime.now() - dd 
	def getTestFileName(self, isTrace):
		testname = ""
		if (isTrace):
			testname = "Test_trace_" + str(self.currentspecnro) + ".txt"
		else:
			testname = "No_test_possible_" +  str(self.currentspecnro)+ ".txt"
		tn = os.path.join(self.logdir, testname)
		return tn
	def logTestRequirements(self, conditions):
		for i in range(0,len(conditions)):
			stri = "Test requirement " + str(i+1) + ":" + conditions[i]
			self.conditions.append(stri)
	def getNuSMVoutputfile(self):
		f = os.path.join(self.tempdir, self.NuSMVoutputfile)
		return f
	# print all statistic data to the logfiles
	def printStatisticsLog(self):
		f = os.path.join(self.logdir, self.logname)
		log = open(f, 'a')
		print >> log, "Log:"
		
		# tulostetaan generoidut testiehdot
		print >> log, "Generated test requirements: (", len(self.conditions), ")"
		for x in self.conditions:
			print >> log, x
		
		
		print >> log, "Number of infeasible test requirements: ", self.infeasibles
		
		print >> log, "Model checking was run ", self.modelcheckingruns, "times during optimization."
		
		print >> log, "Total test generation time:", self.totaltime, "seconds."
		
		
		
		# Mapping 
		print >> log, "Mapping from test requirements to tests."
		for key, value in self.mapping.items():
			print >> log, "Test number " + str(key) + " satisfies test requirements ",
			for v in value:
				print >> log, str(v+1) ,
			print >> log
		print >> log 
		
		# Tulostetaan my�s proceduressa olleet rivit
		for p in self.procedure:
			print >> log, p
		
		log.close()

# A class for storing function block type related data. 
# For example AND function block type has : 2 inputs, 1 output,  related function block conditions ...
class Conditions:
	#All the information is read from a file
	# One FB is specified on a single line 
	# ':' is a separator between data items on that line
	def __init__(self, conditionfile):
		try:
			cf = open(conditionfile)
		except:
			print "Could not open file with function block conditions."
			sys.exit(1)
		lines = cf.readlines()
		cf.close()
		self.FBCfunction = {}	# the mapping from FB type (string) to a FUNCTION that gives out the correct function block conditions AND --> function
		self.IOnumbers = {}	# the mapping from FB type (string) to number of inputs and outputs , e.g.  AND --> [2, 1]
		self.usedinputs = {}		# the mapping from FB type (string) to a list where item on index i tells whether that input should be used in this program (parameters are not used) e.g. PULSE --> [True, False]
		self.FBoutputs = {}		# the mapping from FB type (string) to its outputs. e.g. AND --> [output1]
		self.booleanoutputs = {}	# # the mapping from FB type (string) to a list where item on index i tells whether that output is boolean. e.g. AND --> [True]
		self.typeteller = {}		# a  mapping that is used for finding out the smv-module type of an instance, e.g. typeteller['AND12'] = AND
		
		print "Loading function block conditions from file", conditionfile
		for l in lines:
			if l.startswith('--'):
				continue
			# Line format :<FB module type>:<nro of inputs>:<nro of outputs>:<used inputs marked with 1 / unused 0>: <boolean outputs marked with 1> : <outputs separated with ','>:[function block conditions in the order: in1 -> out1 , in1 -> out2 ... in2->out1, in2->out2 ...]
			tempfbcond = l.strip().split(':') 
			fbname = tempfbcond[0]
			numberofinputs = int(tempfbcond[1])
			numberofoutputs = int(tempfbcond[2])
			conds = []	# list of function block conditions
			IOrelations = [] #  list that maps the function block conditions in 'conds' to related input and output indeces e.g. [[0,0],[1,0]]
			
			usedInputsData = []
			numberofusedinputs = 0
			for j in range(0, len(tempfbcond[3])): # inputs that are used in the program
				if tempfbcond[3][j]=='1': 
					usedInputsData.append(True)
					numberofusedinputs = numberofusedinputs +1
				else:
					usedInputsData.append(False)
			self.usedinputs[fbname] = usedInputsData
			
			boolOutputs = []# The outputs that are boolean marked with True
			for j in range(0, len(tempfbcond[4])): 
				if tempfbcond[4][j]=='1': 
					boolOutputs.append(True)
				else:
					boolOutputs.append(False)
			self.booleanoutputs[fbname] = boolOutputs
			
			# Read the list of outputs:
			outputlist = tempfbcond[5].split(',') 
			self.FBoutputs[fbname] = outputlist
			
			# The remaining items are the function block conditions
			for x in range(6, len(tempfbcond)):
				conds.append(tempfbcond[x])
			
			# create a mapping between the conditions and the input / output indeces
			for i in range(0, numberofoutputs):
				for j in range(0, numberofusedinputs):
					IOrelations.append([j, i])
					
			print "Found function block condition for: ", fbname
			self.FBCfunction[fbname] = createFunction(IOrelations, conds)
			self.IOnumbers[fbname] = [numberofinputs, numberofoutputs]
		
		# Create 'branch' function block types, that are used to create only point to point edges
		self.FBCfunction['--2BRANCH'] = createFunction([[0, 0],[0,1]], [" TRUE ", " TRUE "])
		self.FBCfunction['--3BRANCH'] = createFunction([[0, 0],[0,1],[0,2]], [" TRUE ", " TRUE ", " TRUE "])
		self.FBCfunction['--4BRANCH'] = createFunction([[0, 0],[0,1],[0,2],[0,3]], [" TRUE ", " TRUE ", " TRUE ", " TRUE "])
		self.IOnumbers['--2BRANCH'] = [1, 2]
		self.IOnumbers['--3BRANCH'] = [1, 3]
		self.IOnumbers['--4BRANCH'] = [1, 4]
		self.usedinputs['--2BRANCH'] = [True, True]
		self.usedinputs['--3BRANCH'] = [True, True, True]
		self.usedinputs['--4BRANCH'] = [True, True, True, True]
		self.FBoutputs['--2BRANCH'] = "non"
		self.FBoutputs['--3BRANCH'] = "non"
		self.FBoutputs['--4BRANCH'] = "non"
	
	# returns True if the output of the FB at index ind is boolean
	def getType(self, fb, ind):
		return self.booleanoutputs[self.typeteller[fb.name]][ind] 
	
	# add a new mapping from FB instance to a type
	def addTypeMapping(self, instancename, fbtype):
		self.typeteller[instancename] = fbtype	# add mapping from instance to the type
	
	# returns True / False, whether the input at index i is marked to be used or not
	def isInputUsed(self, fb, i):
		return self.usedinputs[self.typeteller[fb.name]][i]
	
	# input is a string of a FB instance.
	# returns the list of outputs this FB has
	def getListofFBOutputs(self, fb):
		return self.FBoutputs[self.typeteller[fb]]

# A data structure for edges. Edges are the lines between function blocks and the lines coming from inputs or to the outputs.
class Edge:
	def __init__(self, tyyppi, input, i_index, output, o_index, boo, nimi):
		self.type = tyyppi 			# input/ output / connector / loopend
		self.inputFB = input			# The function block instance that sends data through this edge
		self.outputFB = output		# The function block instance that receives data through this edge
		self.inputindex = i_index		# The index at which this edge is connected in the sending FB (the output index of that FB)
		self.outputindex = o_index		# The index at which this edge is connected in the receiving FB (the input index of that FB)
		self.boolean = boo			# whether this edge carries boolean information
		self.name = nimi			# The name that can be used to refer to the information on this edge
		self.outputname = ""
		self.connect()
	# make the connections to the FBs on both ends
	def connect(self):
		if (self.inputFB != None):
			self.inputFB.connectOutput(self.inputindex, self)
		if (self.outputFB != None):
			self.outputFB.connectInput(self.outputindex, self)
		return
	def getName(self):
		return self.name
	def setOutputName(self, name):
		self.outputname = name
	def getOutputName(self):
		if self.outputname == "":
			return self.name
		return self.outputname 
	def isBoolean(self):
		if (self.boolean == True):
			return True
		else: 
			return False
	def printEdge(self):
		print "Edge:", self.name,
		print "from ", 
		if self.inputFB: 
			print self.inputFB.name,
		else: 
			print "None",
		print "to ",
		if self.outputFB: 
			print self.outputFB.name,
		else:
			if self.type == "output":
				print "Output",
			else: 
				print "None, (loop cut here)"
		print

# A class for the function blocks 
class FunctionBlock:
	def __init__(self, nimi, c_f, nro_of_inputs, nro_of_outputs, inputs):
		self.inputedges = []	# List of function block inputs in the correct order. Initialized as none. Type Edge.
		self.outputedges = []	# List of function block outputs. Type edge
		self.listofinputs = inputs # List of inputs, type string
		self.name = nimi	# The name that is used to refer to this function block in the SMV-model
		for x in range(0, nro_of_inputs):	# initialize the inputs and outputs as None. Later the connectInput/Output function is used to make the connections
			self.inputedges.append(None)
		for x in range(0, nro_of_outputs):
			self.outputedges.append(None)
		self.conditionfunction = c_f
	def connectInput(self, index, edge): # Create the connections to the Edges
		self.inputedges[index] = edge
	def connectOutput(self, index, edge):
		self.outputedges[index] = edge
	def getName(self):
		return self.name
	
	# returns a list of the indeces of the function blocks inputs that are connected to "input" parameter
	def getConnectedInputIndeces(self, input):
		list = []
		for i in range(0, len(self.listofinputs)):
			if input == self.listofinputs[i]:
				list.append(i)
		return list
	def printFB(self):
		print "Block name: ", self.name
		print "Inputs: "#, len(self.inputedges)
		for i in self.inputedges:
			if (i != None):
				print "\t",i.getName()
			else:
				print "\tNone"
		print "Outputs: "
		for o in self.outputedges:
			if (o!= None):
				print "\t",o.getName()
			else:
				print "\tNone"
		print ""
			

# A class for the whole function block diagram
# When initialized, reads the smv-file and creates appropriate function blocks and the edges between them.
# Breaks loops where necessary, and creates branching function blocks to make point-to-point edges only.
class FunctionBlockDiagram:
	def __init__(self, FBDfilename, conditiondata):
		self.filename = FBDfilename
		self.FBs = [] 			# list of the function blocks in the FBD
		self.FBDinputs = []		# list of edges of type "input"
		self.FBDoutputs = []		# list of edges of type "output"
		self.FBDconnectors = []	# list of edges of type "connector" or "loopend"
		self.FBconditions = conditiondata	# The Conditions -class datastructure that holds all the information related to the function blocks
		self.branches = 0		# how many branch type FBs are created. used for creating individual names for the new branch FBs.
		
			
		# Open the smv-file and read the contents
		try:
			fn = open(FBDfilename)
			lines = fn.readlines()
			fn.close()
		except:
			print "Could not open FBD model: ", FBDfilename
			sys.exit(1)
		
		# read lines and parse out the lines that deal with inputs, function blocks and outputs
		inputdeclarations, FBdeclarations, outputdeclarations = self.readModelLines(lines)
		
		# create FunctionBlock data structures based on the model declarations
		self.createFunctionBlocks(FBdeclarations)
		
		# Create Input edges based on the model declarations
		self.createInputs(inputdeclarations)
		
		# create Edges between the function blocks. 
		# create also branch function blocks for signals that go from a single source to multiple receiving ends
		# if an edge is connected to both a function block and to an output the output edge is also created here
		self.createConnectingEdges(outputdeclarations)
		
		# create remaining outputs not created in the previous phase
		self.createOutputs(outputdeclarations)
		
		# Check if there are loops and remove loops where necessary
		loopedge = self.getLoopEdge()
		while loopedge != None:
			self.removeLoopEdge(loopedge)
			loopedge = self.getLoopEdge()
			
	
	# Removes an edge that is causing a loop, and replaces it with two new edges. One leading nowhere and a new input
	def removeLoopEdge(self, loopedge):
		# the edge causing a loop cannot be input / output /loopend. It must be a connector edge
		inputfb = loopedge.inputFB	# the FB in the sending end of the loopedge
		outputfb = loopedge.outputFB	# the FB in the receiving end of the loopedge
		ii = loopedge.inputindex		# index at which connected
		oi = loopedge.outputindex
		b = loopedge.boolean 		# is it a boolean edge
		name =loopedge.name 		# name at which the edge is referred
		type = loopedge.type			# this should be connector (not used)
		
		self.FBDconnectors.remove(loopedge)	# remove from the  FBD
		# Add new edge from the sending FB to None
		self.addConnection("loopend", inputfb, ii, None, -1,  b, name + "loopend")
		
		# a new input: to the receiving FB
		newinput  = Edge("input",  None, -1, outputfb, oi,  b, name )
		self.FBDinputs.append(newinput)
		
	# a function for finding an edge in the FBD that causes a loop 
	# if no such edges are found, return None
	# loops are found by travelling the FBD backwards starting from the outputs in depth-first-manner
	# If a function block is encountered that has already been visited, a loop is found
	def getLoopEdge(self):
		for o in self.FBDoutputs: # search for loops from all outputs
			loopingedge = self.LoopSearchDFS(o.inputFB, [])
			if loopingedge != None:
				return loopingedge
		return None
	
	# A recursive function for depth-first-search.
	# travels the FBD backwards and returns an edge that causes a loop
	# if not found, return None
	# the parameter v is the function block that we are currently in
	# the parameter discovered is the list of FBs that have been visited previously
	def LoopSearchDFS(self, v, discovered):
		discovered.append(v)
		# go trough the inputs of this FB:
		for e in v.inputedges:
			if e != None:	# has to be connected to some edge
				if e.inputFB != None:	# edge has to be connected to a FB (not an input)
					if e.inputFB in discovered:	# if already visited the connecting edge makes the loop, and is returned
						return e
					if not e.inputFB in discovered:	# not visited before -> recursive call
						tempvalue = self.LoopSearchDFS(e.inputFB, discovered)
						discovered.pop() # after the recursive call, pop the element at top 
						if tempvalue != None: # if some edge was returned from recursive call, return it
							return tempvalue
		return None # No edge found
		
	
	# a procedure for reading the lines of the smv-model
	# returns 3 lists the lines that have the input / output / and FB declarations
	def readModelLines(self, lines):
		inputsection = False
		outputsection = False
		FBsection = False
		inputdeclarations = []
		FBdeclarations = []
		outputdeclarations = []
		for l in lines:
			if 'INPUTSTART' in l:	# These keywords are used to annotate the SMV-file.  E.g. lines between INPUTSTART and INPUTSTOP have input declarations.
				inputsection = True
				continue
			if 'INPUTSTOP' in l:
				inputsection = False
				continue
			if 'OUTPUTSTART' in l:
				outputsection = True
				continue
			if 'OUTPUTSTOP' in l:
				outputsection = False
				continue
			if 'FBSTART' in l:
				FBsection = True
				continue
			if 'FBSTOP' in l:
				FBsection = False
				continue
			if l.strip() == '':	# skip empty lines
				continue
			if l.strip().startswith('--'): # skip comments
				continue
			if FBsection:
				FBdeclarations.append(l.strip())
			if inputsection:
				inputdeclarations.append(l.strip())
			if outputsection:
				outputdeclarations.append(l.strip())
		
		return inputdeclarations, FBdeclarations, outputdeclarations 
	
	# a function for creating the FunctionBlock instances based on the lines in the SMV-model
	def createFunctionBlocks(self,FBdeclarations):
		# parsing the lines in the model 
		for fb in FBdeclarations:
			firstpart = re.compile('(.*?)\:')	# the instance name search
			typepart = re.compile('\:(.*?)\(')	# the FB type search
			brackets = re.compile('\((.*?)\)')	# between parenthesis search
			
			instancename = firstpart.search(fb).group(1).strip()
			fbtype = typepart.search(fb).group(1).strip()
		
			self.FBconditions.addTypeMapping(instancename, fbtype)
			
			fbinputsraw = brackets.search(fb).group(1).split(',') # read the inputs of the FB that are between parenthesis
			fbinputs = []
			for ti in fbinputsraw:
				fbinputs.append(ti.strip())
			try:
				ins_and_outs = self.FBconditions.IOnumbers[fbtype]	# the number of inputs and outputs of the FB are read from the FBconditions data structure
			except:
				print "Could not find FB type ",fbtype," in function block conditions"
				sys.exit(1)
			nro_of_inputs = ins_and_outs[0]
			nro_of_outputs = ins_and_outs[1]
			createdFunctionBlock = FunctionBlock(instancename, self.FBconditions.FBCfunction[fbtype], nro_of_inputs, nro_of_outputs, fbinputs)
			# add the created function block to the list of function blocks
			self.FBs.append(createdFunctionBlock)
	
	# function for creating the input edges based on the lines in the SMV-model
	def createInputs(self, inputdeclarations):
		for inp in inputdeclarations:
			firstpart = re.compile('(.*?)\:')		# name of input  ends with ':'
			secondpart = re.compile('\:(.*?)\;')	# the type part is between ':' and ';'
			name = firstpart.search(inp).group(1).strip()
			type = secondpart.search(inp).group(1).strip()
			if type == 'boolean': 
				type = True
			else:
				type = False
			
			#get a list of FBs that this input is connected to, and the indeces of the connections
			connectedfbs, indexes = self.getFBConnectionsOfInput(name)
			
			# based on the connections, create the Edge-instances and branching FBs when needed:
			createdInputs = self.createInputEdges(connectedfbs, indexes, type, name)
			
			# add the created inputs to the FBD
			for t in createdInputs:
				self.FBDinputs.append(t)
	
	# a function for creating the connectors between the FBs and between inputs and FBs.
	# new Branch-FBs are created if needed and also outputs are created if they are connected to a branch
	def createConnectingEdges(self, outputdeclarations):
		tempFBs = []	# list of FBs (branches that are created during this procedure
		
		# go through the FBs of the FBD
		for fb in self.FBs:
			for i in range(0, len(fb.listofinputs)): # go through the inputs of the FB
				# Check if the input is used (in input info, is the input index marked True of False) or a parameter
				if not self.FBconditions.isInputUsed(fb, i):
					continue
				# a connecting edge might already exist if the same input is connected to other FBs that have already been gone through.
				if self.connectorAlreadyExists(fb.listofinputs[i]):
					continue
				
				# if the input is an input of the FBD and not a connector:
				if (self.isThisAnFBDInput(fb.listofinputs[i])):
					continue
				
				# A connecting edge for the input has not yet been created. 
				# First, get a list of all FBs and outputs that the input is connected to (so that the connections to all are created at the same time)
				fbs, inds = self.getAllFBsWithSameInput(fb.listofinputs[i]) 					
				nameofoutput, existsoutput = self.existsConnectedOutput(fb.listofinputs[i], outputdeclarations) #is the variable also connected to an output
				
				# nroofconnections is the number of places this input variable is connected to
				if existsoutput:
					nroofconnections = len(fbs) + 1
				else: 
					nroofconnections = len(fbs)
				if nroofconnections == 0: # For some reason the input is not connected to anything, error?
					print fb.listofinputs[i], "not connected to anything (?)"
					continue
				
				# the current input must originate from a single source
				# Find out the FB that 'sends' the variable:
				sendingFB = None
				sendingindex = -1 
				firstpart = re.compile('(.*?)\.')
				sendingmodname = firstpart.search(fb.listofinputs[i]).group(1).strip() # name of the module that sends the input is before the dot
				varname = fb.listofinputs[i].split('.')[-1] # The last part of the input after a dot (Note. Assume that there are only two parts "PART1.PART2"
				
				# go through the outputs of the FB that corresponds to the sending FB name
				for j in range(0, len(self.FBconditions.getListofFBOutputs(sendingmodname))): 
					if self.FBconditions.getListofFBOutputs(sendingmodname)[j] == varname:	# is the output name the same as the variable part of the current input
						sendingindex = j	# found the correct index of the output
						for temp in self.FBs:	# find the FB that corresponds to the string sendingmodname
							if sendingmodname == temp.name:
								sendingFB = temp
								break
						break
				temptype = self.FBconditions.getType(sendingFB, sendingindex) 	# get the type of the output
				# If there are more than 1 place the input is going to, we must create a branching FB inbetween
				if nroofconnections > 1:
					# get a branch FB name (assume that the same name is not used in the model)
					branchname = "branch"+str(self.branches)
					self.branches = self.branches +1
					branchtype = "--"+str(nroofconnections) + "BRANCH" 
					self.FBconditions.addTypeMapping(branchname, branchtype) # Add a mapping from the FB name to the FB type
					
					# Create the new branch FB, the number of outputs depends on whether an output exists also
					if existsoutput:
						tempbranch = FunctionBlock(branchname, self.FBconditions.FBCfunction[branchtype], 1, len(fbs)+1, [fb.listofinputs[i]]) 
					else:
						tempbranch = FunctionBlock(branchname, self.FBconditions.FBCfunction[branchtype], 1, len(fbs), [fb.listofinputs[i]]) 
					
					tempFBs.append(tempbranch) # add the created FB to the list of new FBs
					
					# Create the connection from the sending FB to the new branch
					self.addConnection("connector", sendingFB, sendingindex, tempbranch, 0,  temptype, fb.listofinputs[i])
					# create the connections from the branch FB to all the receiving FBs
					for c in range(0, len(fbs)):
						self.addConnection("connector", tempbranch, c, fbs[c], inds[c],  temptype, fb.listofinputs[i])
					# create the connection to an output if needed. Multiple edges are not needed. Assuming that there can not be two same outputs
					if existsoutput:
						tempoutput  = Edge("output", tempbranch, len(fbs), None, -1,  temptype, fb.listofinputs[i])
						tempoutput.setOutputName(nameofoutput)
						self.FBDoutputs.append(tempoutput)
					continue
				# if the input is only connected to a single FB, create the connection to that FB
				if nroofconnections == 1:
					self.addConnection("connector", sendingFB, sendingindex, fbs[0], inds[0],  temptype, fb.listofinputs[i])
					continue
		# Add the created branch FBs to the list of FBs in the FBD
		for t in tempFBs:
			self.FBs.append(t)
	
	# checks if the inputname is one of the inputs of the FBD
	def isThisAnFBDInput(self, inputname):
		for input in self.FBDinputs:
			if input.name == inputname:
				return True
		return False
		
	# function for creating the remaining output edges based on the lines in the SMV-file
	# some outputs may have been previously created
	def createOutputs(self, outputdeclarations):
		for out in outputdeclarations:
			firstpart = re.compile('(.*?)\:')
			secondpart = re.compile('\=(.*?)\;')
			tempname = firstpart.search(out).group(1).strip()
			output_variablename= secondpart.search(out).group(1).strip()
			
			fb, ind  = self.getConnectedFB(output_variablename)	# get the FB and index this variable is connected to
			
			# create output edge if needed
			if not self.outputAlreadyexists(output_variablename):
				temptype = self.FBconditions.getType(fb,ind) 
				tempoutput  = Edge("output", fb, ind, None, -1,  temptype, output_variablename)
				tempoutput.setOutputName(tempname)
				self.FBDoutputs.append(tempoutput)
	
	# checks whether an output Edge with the same name has already been made
	def outputAlreadyexists(self, outputname):
		for o in self.FBDoutputs:
			if o.name == outputname:
				return True
		return False
	
	# checks whether a connecting edge with the same name has already been created
	def  connectorAlreadyExists(self, variablename):
		for e in self.FBDconnectors:
			if e.getName() ==  variablename:
				return True
		return False
	
	# checks whether an output exists in the smv-file that has the name outputname
	def existsConnectedOutput(self, outputname, outlines):
		for out in outlines:
			firstpart = re.compile('(.*?)\:')
			secondpart = re.compile('\=(.*?)\;')
			tempname = firstpart.search(out).group(1).strip()
			tempconnection= secondpart.search(out).group(1).strip()
			if (tempconnection == outputname):
				return tempname, True
		return  "", False
	
	# returns a lists of function blocks and indeces that have the String 'input' as one of the inputs
	# the 'input' is assumed to be a connecting edge between FBs and not of type input
	def getAllFBsWithSameInput(self, input): # input = e.g. AND2.OR1.output
		# If the input does not have a '.' in it it does not come from another module
		if not '.' in input:
			return [],[]
		modulesearch = re.compile('(.*?)\.')	# part on the left side of the dot
		fbname = modulesearch.search(input).group(1).strip()
		varname = input.split('.')[-1]
		fbs = []
		indeces = []
		for f in self.FBs:
			for i in range(0, len(f.listofinputs)):
				if f.listofinputs[i] == input:
					fbs.append(f)
					indeces.append(i)
		return fbs, indeces

	# Create input edge with tempname
	# connectedfbs and indexes are lists. If the lists are longer than 1 item a branching FB is also created.
	# temptype tells whether the input is of boolean type.
	# returns a list with all the new input type edges.
	def createInputEdges(self, connectedfbs, indexes, temptype, tempname):
		edges = []
		if len(connectedfbs)== 1:
			temp = Edge("input", None, -1, connectedfbs[0], indexes[0],  temptype, tempname)
			edges.append(temp)
		
		if len(connectedfbs)>1:
			branchname = "branch"+str(self.branches)
			self.branches = self.branches +1
			branchtype = "--"+str(len(connectedfbs)) + "BRANCH"
			self.FBconditions.addTypeMapping(branchname, branchtype)
			tempbranch = FunctionBlock(branchname, self.FBconditions.FBCfunction[branchtype], 1, len(connectedfbs), [tempname])
			self.FBs.append(tempbranch)
			temp = Edge("input", None, -1, tempbranch, 0,  temptype, tempname) # create the edge to the new branch
			edges.append(temp)
			# create the edges from the branch to the FBs
			for c in range(0, len(connectedfbs)):
				self.addConnection("connector", tempbranch, c, connectedfbs[c], indexes[c],  temptype, tempname)
		return edges
	
	# a function that has a variable name (string) as input
	# returns the FB and index of the function block that has this variable as output
	def getConnectedFB(self, outputname):
		modulesearch = re.compile('(.*?)\.')	# searching for the part on the left of the dot
		fbname = modulesearch.search(outputname).group(1).strip()
		varname = outputname.split('.')[-1]	# the variable name is on the right of the dot
		connectedfb = None
		connectedindex = -1
		for f in self.FBs:
			if f.name == fbname:
				connectedfb = f	# found the FB
				outs = self.FBconditions.getListofFBOutputs(f.name)
				# get the index of the output
				for o in range(0, len(outs)):
					if outs[o] == varname:
						connectedindex = o
		return connectedfb, connectedindex
		
	# a function that has a variable name as input
	# returns lists of FBs and indeces that tell where that variable is connected as an input.
	def getFBConnectionsOfInput(self, inputname):
		connectedfbs = []
		connectedinds = []
		for f in self.FBs:
			indeces = f.getConnectedInputIndeces(inputname) # what input indexes are connected to inputname (several are possible in theory)
			if len(indeces) > 0:
				for i in indeces:
					connectedfbs.append(f)
					connectedinds.append(i)
		return connectedfbs,connectedinds
	
	# create a connecting edge between two function blocks, and add the edge to the list of connector edges
	def addConnection(self, tyyppi, fb1, fb1index,  fb2, fb2index, boo, nimi):
		e = Edge(tyyppi, fb1, fb1index,  fb2, fb2index, boo, nimi)
		self.FBDconnectors.append(e)
		return e

	def printFBD(self):
		print "\nFBD derived from", self.filename, ":"
		print "-------------------------------------"
		print "Function block instances:"
		for fb in self.FBs:
			print "------"
			fb.printFB()
			
		print "-------------------------------------"
		print "Inputs:"
		for c in self.FBDinputs:
			c.printEdge()
		print "-------------------------------------"
		print "Connectors:"
		for c in self.FBDconnectors:
			c.printEdge()
		print "-------------------------------------"
		print "Outputs:"
		for c in self.FBDoutputs:
			c.printEdge()

# returns the function foo that returns the function block condition (type string) between an inputindex and an outputindex of a functionblock
def createFunction(combinations, strings):
	def foo(inputedgeindex, outputedgeindex, functionblock):
		combs = combinations	# this is the list of input-output relations, e.g. [[0,0], [1,0], [2,0]]
		fb = functionblock
		s = ""				# outputted string
		for x in range(0, (len(combinations))):
			if ((inputedgeindex == combs[x][0])  & (outputedgeindex == combs[x][1])):
				s = strings[x]
				compstring = "%FB%"
				s = s.replace(compstring, fb.getName())  # replace the string %FB% with the FB name
				for y in range (0, len(fb.inputedges)):
					if fb.inputedges[y] == None:
						continue
					compstring = "%i" + str(y)+ "%"
					s = s.replace(compstring, fb.inputedges[y].getName()) # replace the inputs in the condition with the inputs that are connected to the FB
				return s
		print "Condition not found"
		return s
	return foo

# a recursive function for finding data paths in the function block
# input: edge - the current edge we are examining
# input: curpath - the list of edges on the current path 
# input: allpaths - list of all of the paths that have so far been found in the FBD
# returns a list of paths of the FBD. A path is a list of Edges. 
# so we return a list of list of Edges
def findPath(edge, curpath, allpaths):
	newcurpath = []
	for p in curpath: # make a copy of the curpath
		newcurpath.append(p)
	newcurpath.append(edge)	# add the current edge to this copy
	newallpaths = []	# make a copy of allpaths
	for p in allpaths:
		newallpaths.append(p)
	
	# if the current edge breaks a loop, the edge leads nowhere, and we should not look further. -->  return with no new paths:
	if (edge.type == 'loopend'): 
		return newallpaths
	
	# If the current edge is of type 'output' we have found a path from an input to an output
	# add current path to the list of found paths and return the paths.
	if ( edge.type == 'output'):
		newallpaths.append(newcurpath)
		return newallpaths
	
	# otherwise, recursively check the output edges of the function block that is encountered.
	for e in edge.outputFB.outputedges:
		npaths = findPath(e, newcurpath, newallpaths)
		for p in npaths:
			newallpaths.append(p)
	return newallpaths

# a function for finding data paths of a FBD.
# makes the call the findPath
def CreateDPaths(FBD):
	dpaths = []
	# starting from all inputs: find paths
	for input in FBD.FBDinputs:
		paths = findPath(input, [], [])
		for p in paths:
			dpaths.append(p)
	# remove possible duplicants
	retpaths = []
	for p in dpaths:
		if (p in retpaths):
			continue
		else: 
			retpaths.append(p)
	return retpaths

def printDPaths(dPaths):
	print "\n-----------------------------------"
	print "D-paths found (", len(dPaths), "):" 
	for path in dPaths:
		print "D-path: <",
		for e in path:
			print e.getName(), 
		print ">"

# a function for determining the data path conditions of a list of data paths 'dpaths'
# returns a list of strings that are the datapathconditions
def CreateDPathConditions(dpaths):
	# a data path condition is a conjunction of function block conditions
	# we go through the paths one by one.
	# take two neighbouring edges of the path. these edges form a single function block condition: FB.conditionfunction(i_ind, o_ind, FB)
	dpathconditions = []
	for path in dpaths:
		condition = "("
		for index in range(0, len(path)):
			# Unless this is the last edge (output), this and the next edge produce a function block condition
			if (path[index].type == 'output'): 
				continue
			
			iindex = path[index].outputindex	# The outputindex of the edge is the input index of the FB and vice versa
			oindex = path[index+1].inputindex
			
			fb = path[index].outputFB
			if index == 0:
				condition = condition + fb.conditionfunction(iindex, oindex, fb)
			else:
				condition = condition + " & " + fb.conditionfunction(iindex, oindex, fb)
		condition = condition + ")"
		dpathconditions.append(condition)
	return dpathconditions

def printDPCs(dpcs):
	i = 1
	for dpc in dpcs:
		print "D-path condition" , i, ":", dpc
		i = i+1

# a function for generating  a single temporal specification from a list of test requirements given as strings
# the temporal specification is false when all the requirements given as input are true at some point
def CreateTemporalSpecification(requirementlist):
	if (len(requirementlist) == 1):
		spec = "LTLSPEC G !" + requirementlist[0] + ";"
		return spec
	spec = "LTLSPEC "
	for x in range(0, len(requirementlist)):
		if (x== len(requirementlist)-1): # if we are at the last element, end the formula with ");"
			spec =  spec + "G !("  + requirementlist[x] + ");"
		else:
			spec =  spec + "G !("  + requirementlist[x] + ") | "
	return spec
	
def printSpecifications(specs):
	i = 1
	for s in specs:
		print "Specification ",i,":", s
		i = i+1

# a function for creating a set of test requirements according to the ICC test criterion
# inputs are a set of data paths dpaths and a set of data path conditions DPCs
def createICCtestRequirements(dpaths, DPCs):
	testrequirements = []
	for x in range(0, len(dpaths)):
		if (dpaths[x][0].isBoolean()): # If the first edge of the path is boolean we add 2 special conditions according to the ICC criterion:
			cond1 = "(" +    dpaths[x][0].getName() + " & " + DPCs[x] + ")"
			cond2 = "( ! " + dpaths[x][0].getName() + " & " +  DPCs[x] + ")"
			testrequirements.append(cond1)
			testrequirements.append(cond2)
		else:
			testrequirements.append(DPCs[x])
	return testrequirements

# a function for creating a set of test requirements according to the CCC test criterion
# inputs are a set of data paths dpaths and a set of data path conditions DPCs
def createCCCtestRequirements(dpaths, DPCs):
	testrequirements = []
	for x in range(0, len(dpaths)):
		addBasicRequirement = True	# If there are no boolean edges along the path we just add the DPC itself as a test requirements
		for y in range(0, len(dpaths[x])): # go through the edges of the d-path
			if (dpaths[x][y].isBoolean()): # According to CCC, if the edge is boolean, we add two requirements
				req1 = "(" +    dpaths[x][y].getName() + " & " + DPCs[x] + ")"
				req2 = "( ! " + dpaths[x][y].getName() + " & " +  DPCs[x] + ")"
				testrequirements.append(req1)
				testrequirements.append(req2)
				addBasicRequirement = False 
		if (addBasicRequirement):	
			testrequirements.append(DPCs[x])
	return testrequirements
	


	
# a function for generating a new temporary model file
# in which the temporal specification spec has been placed in.
def generateModel(modelfile, spec, stats):
	# get the name of the tempfile from stats
	tempfile = open(stats.getTempModelFilename(), 'w')
	# read the model file
	main = open(modelfile)
	mainlines = main.readlines()
	main.close()
	inmainmodule = False
	for l in mainlines:
		if (l.strip().startswith('LTLSPEC')): # leave out all specifications
			continue
		if (l.strip().startswith('CTLSPEC')):# leave out all specifications
			continue
		if (l.strip().startswith('INVARSPEC')):# leave out all specifications
			continue
		if (l.startswith('MODULE') & inmainmodule): # Some other module declaration begins after the main module. We want to add the specification here
			inmainmodule = False
			print >> tempfile, spec
			print >> tempfile, l,
			continue
		if (l.startswith('MODULE main')):
			inmainmodule = True
		print >> tempfile, l,
	tempfile.close()
	return tempfile

# a function for running the temp file on NuSMV using BDD algorithm
def runBDDModelChecking(temp, stats):
	# create a command file for NuSMV:
	cmdfile = open(stats.getCMDfile(), 'w')
	print >> cmdfile, "set on_failure_script_quits"
	print >> cmdfile, "go"
	print >> cmdfile, "check_ltlspec"
	print >> cmdfile, "show_traces -p 4 -o "+ stats.getTracefile()
	print >> cmdfile, "quit"
	cmdfile.close()
	
	nusmvcommand = 'NuSMV -int -dynamic -source ' + str(stats.getCMDfile()) + ' ' + str(stats.getTempModelFilename()) 
	
	# create the NuSMV output file:
	f = open(stats.getNuSMVoutputfile(), 'w')
	
	# Run the command file on NuSMV
	args = nusmvcommand.split(' ')
	run2 = subprocess.Popen(args, stdout=f, stderr=subprocess.PIPE)
	
	rcode = 0
	while True:
		rcode = run2.poll()
		if rcode != None:	# If the process has died, break
			f.close()
			break
		time.sleep(0.1)
		
	if (rcode != 0): # non-zero return value received
		print "Error: NuSMV BDD terminated abruptly. Return code:", rcode
		sys.exit(1)
		
# a function for running the temp file on NuSMV using k-induction algorithm
def runModelChecking(temp, stats, bound):
	stats.modelCheckingRun()
	# create a command file for NuSMV:
	cmdfile = open(stats.getCMDfile(), 'w')
	print >> cmdfile, "set on_failure_script_quits"
	print >> cmdfile, "go_bmc"
	print >> cmdfile, "check_ltlspec_bmc -k " + str(bound)
	print >> cmdfile, "show_traces -p 4 -o "+ stats.getTracefile()
	print >> cmdfile, "quit"
	cmdfile.close()
	
	
	nusmvcommand = 'NuSMV -int -dynamic -source ' + str(stats.getCMDfile()) + ' ' + str(stats.getTempModelFilename())  # malli on parametrina saatu mallitiedosto
	f = open (stats.getNuSMVoutputfile(), 'w')
	# Run the command on NuSMV
	args = nusmvcommand.split(' ')
	run2 = subprocess.Popen(args, stdout=f, stderr=subprocess.PIPE)
	
	rcode = 0
	while True:
		rcode = run2.poll()
		if rcode != None:	# Process has ended
			f.close()
			break
		time.sleep(0.1)
		
	if (rcode != 0): # non-zero return value
		print nusmvcommand
		print "Error: NuSMV BMC terminated abruptly. Return code:", rcode
		sys.exit(1)

# opens the NuSMV output from a file and returns:
# 	True if no counter-example was found
# 	False if a counter-example was found
def readResult(stats):
	try:
		result_file = open(stats.getNuSMVoutputfile(), 'r')
		lines = result_file.readlines()
		result_file.close()
	except IOError:
		print "Could not open " + stats.getNuSMVoutputfile()
		sys.exit(1)
	if lines[-1].startswith('-- no counterexample'): # if no proof / counter-example found, this should be on the last line
		return True
	for l in lines:
		if l.startswith('-- specification'):
			if l.endswith('true\n'):
				return True
			if l.endswith('false\n'):
				return False 
	print "Model checking result not found."
	return False

# copy the trace file to the log directory (filename)
def copyTrace(filename):
	shutil.copyfile(stats.getTracefile(), filename)

# create a file to the log directory that has the NuSMV output for an infeasible test requirement
def copyProof(number):
	j = "Test_requirement_"+str(number) + "_infeasible.txt"
	shutil.copyfile(stats.getNuSMVoutputfile(), os.path.join(stats.logdir, j))

# read a NuSMV counter-example from a file and parse the number of states in that counter-example
def readCElength(trace):
	tf = open(trace)
	tulosterivit = tf.readlines()
	tf.close()
	statenumber = 0	
	for i in range(len(tulosterivit)):
		tulosterivit[i] = tulosterivit[i].strip()	#remove whitespace
		if tulosterivit[i].startswith('<state'):	# new state detected
			statenumber = statenumber + 1
			continue
	return statenumber -1


# a function that has as input :
# 	a list of test requirements
# 	the NuSMV model file name
# 	stats instance
#	boolean optimize (whether we try to create test cases that fulfill multiple requirements at once)
# Generates a set of tests by running NuSMV multiple times and reading its counter-examples
# Saves the outputs to the log directory
def createTestSet(testrequirements, modelfile, stats, optimize, FBD):
	stats.logTestRequirements(testrequirements)
	testset = []
	# If not optimize, we want to create a temporal specification for each test requirement
	if (not optimize):
		testmapping = {}	# mapping from the specification numbers to test requirement number it fulfills
		i = 0
		for c in testrequirements:
			i = i+1
			templist = []
			templist.append(c)
			spec = CreateTemporalSpecification(templist)
			temp = generateModel(modelfile, spec, stats)
			runModelChecking(temp, stats, 50)	# here we use a bound of 50 
			specTrue = readResult(stats)
			if (not specTrue):
				stats.newTest()
				copyTrace(stats.getTestFileName(True))
				temptest = createTestCase(stats.getTestFileName(True), FBD)
				testset.append(temptest)
				h = []
				h.append(i-1)
				testmapping[stats.currentspecnro] = h
			else: 
				copyProof(i)
		stats.addTestMapping(testmapping)
	if (optimize):
		print "Optimizing tests."
		
		unchecked_testrequirements = []	# test requirements that are not already satisfied by some test / deemed infeasible
		for c in testrequirements:
			unchecked_testrequirements.append(c)
		fulfilled_testrequirements = []		# test requirements satisfied by some test
		infeasible_testrequirements = []	# infeasible test requirements
		current_testrequirements = []		# set of test requirements currently examined 
		current_testreqs_satisfied = []		# the indeces of the test requirements satisfied
		testmapping = {}				# mapping between test indeces and test requirement indeces
		default_bound = 10				# we first run k-induction using this default bound
		bound_of_last_trace = -1
		useDefaultBound = True
		
		for x in range (0, len(testrequirements)):
			
			if (not (testrequirements[x] in unchecked_testrequirements)): # if the requirement has already satisfied, skip it
				continue
			for y in range(x, len(testrequirements)):
				if (not (testrequirements[y] in unchecked_testrequirements)): #if the requirement has already satisfied, skip it
					continue
				
				# print progress:
				progress = int((float(len(testrequirements)) - float(len(unchecked_testrequirements))) / len(testrequirements) *100)
				print "Processing (", progress , "% done)"
				
				# If x==y, this means that we start from scratch looking for a new test case
				if (x == y):
					current_testrequirements = []
					current_testreqs_satisfied = []
					useDefaultBound = True
					
				current_testrequirements.append(testrequirements[y])
				current_testreqs_satisfied.append(y)		# add this index to satisfied (but remove later if necessary)
				
				# create a temporal specification based on the current test requirements and model check it
				spec = CreateTemporalSpecification(current_testrequirements)
				temp = generateModel(modelfile, spec, stats)
				if (useDefaultBound):
					runModelChecking(temp, stats, default_bound) 
				else: 
					runModelChecking(temp, stats, bound_of_last_trace)
				
				# read the result
				specTrue = readResult(stats)
				
				# If the result was False: counter-example (test case) found
				if (not specTrue):
					copyTrace(stats.temptrace)
					# read its length and use it on later model checking runs
					bound_of_last_trace = readCElength(stats.temptrace)
					
				# Special case: If the spec was true and there is only 1 test requirement we make sure that it is infeasible by running also BDD model checking
				if (specTrue & (len(current_testrequirements) == 1)):
					runBDDModelChecking(temp, stats) 
					altCheck = readResult(stats)
					# BDD could find a (longer than default bound) counter-example
					if (not altCheck):
						specTrue = False # in this case the result is in fact False
						copyTrace(stats.temptrace)
						bound_of_last_trace = readCElength(stats.temptrace)
				
				# No counter-example found:
				if (specTrue): 
					if (len(current_testrequirements) == 1): # only one test requirement in the set
						# the test requirement is infeasible:
						infeasible_testrequirements.append(testrequirements[y])
						msg ="Test requirement:" + str(y +1) + " was infeasible." 
						stats.addInfeasible()
						stats.addAction(msg)
						
						copyProof(y+1)
						# remove from unchecked:
						unchecked_testrequirements.remove(testrequirements[y])
						useDefaultBound = True
						
						break # new value of x
					else: # there were multiple test requirements:
						# remove the current test requirement from the set and
						# continue by checking other test requirements 
						current_testrequirements.remove(testrequirements[y])
						current_testreqs_satisfied.remove(y)
						
						moretestrequirements = False	# Are there any additional test requirements with index y+ left: 
						for i in range(y+1, len(testrequirements)):
							if (testrequirements[i] in unchecked_testrequirements):
								moretestrequirements = True
								break	
						
						if (moretestrequirements): # if some test requirement is unchecked, we continue with a new y value
							useDefaultBound = False
							continue
						else: # no more test requirements: the last tracefile has the test for the current set of test requirements
							stats.newTest()
							shutil.copyfile(stats.temptrace, stats.getTestFileName(True))
							temptest = createTestCase(stats.getTestFileName(True), FBD)
							testset.append(temptest)
							testmapping[stats.currentspecnro] = current_testreqs_satisfied
							useDefaultBound = True
							break # continue with new x value
							
				else: # we have a counter-example:
					moretestrequirements = False	# are there more test requirements left
					for i in range(y+1, len(testrequirements)):
						if (testrequirements[i] in unchecked_testrequirements):
							moretestrequirements = True
							break
					if (moretestrequirements):
						# we mark the current test requirement as fulfilled and continue by checking the other test requirements
						fulfilled_testrequirements.append(testrequirements[y])
						unchecked_testrequirements.remove(testrequirements[y])
						useDefaultBound = False
						continue # continue with another y value
					else:
						# No other testrequirements left
						# create a test based on the current set of test requirements 
						unchecked_testrequirements.remove(testrequirements[y])
						stats.newTest()
						testmapping[stats.currentspecnro] = current_testreqs_satisfied
						for x in current_testrequirements:
							fulfilled_testrequirements.append(x)
						current_testrequirements = []
						current_testreqs_satisfied = []
						copyTrace(stats.getTestFileName(True))
						temptest = createTestCase(stats.getTestFileName(True), FBD)
						testset.append(temptest)
						useDefaultBound = True						
						break	# continue with new x value
		stats.addTestMapping(testmapping)
	return testset

# a procedure that creates a new Test(),
# reads the NuSMV trace is as input and parses it, and
# adds relevant variable assignments to the Test(). Returns the created test.
def createTestCase(tracefilename, FBD):
	#Open NuSMV counter-example
	tf = open(tracefilename)
	lines = tf.readlines()
	tf.close()
	
	test = Test(FBD.FBDinputs, FBD.FBDoutputs)	# Create test case instance
	statenumber = 0
	variablesearch = re.compile('\<value variable=\"(.*?)\"\>')	
	valuesearch = re.compile('\">(.*?)\<')
	for l in lines:
		if ('<state id=' in l):
			statenumber = statenumber +1
			continue
		if ('<value variable=' in l):
			variable = variablesearch.search(l).group(1).strip()	# read variable from trace
			value = valuesearch.search(l).group(1).strip()		# read value of the variable at time point 'state'
			for i in FBD.FBDinputs:
				if variable == i.getName():
					test.addInputValue(variable, statenumber, value)
			for i in FBD.FBDoutputs:
				if variable == i.getName():
					test.addOutputValue(variable, statenumber, value)
	return test

# Print the test set to std.out
def printTestSet(testSet):
	for t in range(0, len(testSet)):
		print '\n-------------------------------------'
		print "Generated test (", t+1,"):"
		testSet[t].printTest()

# open tablename, and save the test case to that file in table form
def saveTestSetAsTable(testSet, tablename):
	lines = []
	for t in range(0, len(testSet)):
		lines.append("-------------------------------------")
		templine =  "Generated test (number"+ str(t+1)+"):"
		lines.append(templine)
		testlines = testSet[t].getPrintLines()
		for t2 in testlines:
			lines.append(t2)
	f = open(tablename, 'w')
	for l in lines:
		print >> f, l
	f.close()
	

# main procedure
if __name__ == '__main__':
	
	# Argument parsing:
	argparser = argparse.ArgumentParser()
	argparser.add_argument('--logname', default="log")
	argparser.add_argument('functionconditions')
	argparser.add_argument('functionblockdiagramfile')
	args = argparser.parse_args()
	dd = datetime.datetime.now()
	print dd
	d = dd.strftime('%d.%m.%Y@%Hh%Mm%Ss')
	d = d.replace(' ', '')
	d = d.replace(':', '')
	logdir = args.logname + '_' + d
	logdir = os.path.join(os.getcwd(), logdir)
	print logdir
	stats = Stats(logdir)

	# read the FB data from the file and create a data structure
	FBconditions = Conditions(args.functionconditions)
	
	# read and create the FBD structure
	functionBD = FunctionBlockDiagram(args.functionblockdiagramfile,  FBconditions) 
	
	# print the FBs and connections
	functionBD.printFBD()
	
	# deduce the data paths of the FBD
	dPaths = CreateDPaths(functionBD)
	printDPaths(dPaths)
	#sys.exit(1)
	
	# deduce data path conditions
	DPCs = CreateDPathConditions(dPaths) 
	printDPCs(DPCs)
	
	# test requirements based on different coverage criteria
	BCC_testrequirements = DPCs
	ICC_testrequirements = createICCtestRequirements(dPaths, DPCs)
	CCC_testrequirements  = createCCCtestRequirements(dPaths, DPCs)
	
	optimize = True	# Test cases that fulfill multiple test requirements at once
	
	# generate the tests
	# NOTE: remove comments from the criterion that needs to be calculated (BCC / ICC / CCC)
	testSet = createTestSet(BCC_testrequirements, args.functionblockdiagramfile, stats, optimize, functionBD)
	#testSet = createTestSet(ICC_testrequirements, args.functionblockdiagramfile, stats, optimize, functionBD)
	#testSet = createTestSet(CCC_testrequirements, args.functionblockdiagramfile, stats, optimize, functionBD)
	
	# Print the tests to screen
	printTestSet(testSet)
	
	# Save the tests to Excel table
	saveTestSetAsTable(testSet, stats.getTestTableName())
	stats.setTime(dd)
	stats.printStatisticsLog()
	print "Model checking run ", stats.getModelCheckingRuns(), "times !"
	print "Done!"
	print datetime.datetime.now() - dd

	