
"""
This module is used to parse definitions from SMV files that has
been flattened (once) with NuSMV. This builds an abstract syntax tree
of how the individual bits are turned into variables. The tree can then be
evaluated with a dictionary that has the values of the bits to get
a full variable.
"""

import re


class SyntaxError(Exception):
	pass


class AST:
	class Expression(object):
		pass

	class Variable(Expression):
		def __init__(self, name):
			self.name = name

		def eval(self, variables):
			if self.name in variables:
				return variables[self.name]
			else:
				return False

		def __repr__(self, indent=""):
			return indent + 'Variable(\'%s\')' % self.name

	class IfThenElse(Expression):
		def __init__(self, cond, iftrue, iffalse):
			self.cond = cond
			self.iftrue = iftrue
			self.iffalse = iffalse

		def eval(self, variables):
			if self.cond.eval(variables):
				return self.iftrue.eval(variables)
			else:
				return self.iffalse.eval(variables)

		def __repr__(self, indent=""):
			return 'IfThenElse(%s, %s, %s)' % (self.cond, self.iftrue, self.iffalse)

	class Number(Expression):
		def __init__(self, value):
			self.value = value

		def eval(self, variables):
			return self.value

		def __repr__(self, indent=""):
			return indent + 'Number(%d)' % self.value


class Parser:
	def get_definitions_from_code(self, code):
		"""
		Return a dictionary of definitions where the definition's name
		is the key. Definitions can then be evaluated with
		`definition.eval(variables)`.
		"""
		self.position = 0
		self.code = code

		definitions = dict()

		# Find a define block
		while self.position < len(self.code):
			self._skip_whitespace()
			if self._is_next('DEFINE'):
				self._expect('DEFINE')

				# Loop through all definitions in the block
				while True:
					definition = self._parse_definition()
					if definition is None:
						continue
					if definition is False:
						break
					definitions[definition[0]] = definition[1]

			self._goto_next_line()
		return definitions

	def _parse_definition(self):
		try:
			self._skip_whitespace()
			ident = self._expect_identifier()
			self._skip_whitespace()
			self._expect(':=')
		except SyntaxError:
			# Not a definition, must be something else
			return False

		# These are internal definitions that we are not interested in
		if ident.startswith('__expr'):
			return None

		stack = []

		# Convert the definition string to tokens and push them to the stack
		while True:
			self._skip_whitespace()

			if self._is_next_char(r'\('):
				self._next()
				stack.append('(')

			elif self._is_next_char(r'\)'):
				self._next()
				stack.append(')')

			elif self._is_next_char(r'[A-Za-z_]'):
				stack.append(AST.Variable(self._expect_identifier()))

			elif self._is_next_char(r'[0-9]'):
				stack.append(AST.Number(self._expect_number()))

			elif self._is_next_char(r'\?'):
				self._next()
				stack.append('?')

			elif self._is_next_char(r':'):
				self._next()
				stack.append(':')

			elif self._is_next_char(r';'):
				break

			elif self.position >= len(self.code):
				raise SyntaxError("Unexpected EOF")

			else:
				raise SyntaxError("Unexpected character '%s'" % self.code[self.position])

			# Check whether there are tokens on top of the stack
			# that can be simplified to one expression
			while True:
				# If-then-else
				if Parser._stack_end_is(stack, [AST.Expression, '?', AST.Expression, ':', AST.Expression]):
					expr = AST.IfThenElse(stack[-5], stack[-3], stack[-1])
					stack = stack[:-5]
					stack.append(expr)
					continue

				# Parentheses
				if Parser._stack_end_is(stack, ['(', AST.Expression, ')']):
					expr = stack[-2]
					stack = stack[:-3]
					stack.append(expr)
					continue

				break

		self._expect(';')

		# The stack should simplify to one expression
		if len(stack) != 1:
			raise SyntaxError("Definition for '%s' is invalid" % ident)

		return ident, stack[0]

	@staticmethod
	def _stack_end_is(stack, end):
		if len(stack) < len(end):
			return False
		for i in range(-1, -len(end)-1, -1):
			if isinstance(end[i], type):
				if not isinstance(stack[i], end[i]):
					return False
			else:
				if stack[i] != end[i]:
					return False
		return True

	def _next(self):
		self.position += 1

	def _is_next_char(self, regexp):
		if self.position >= len(self.code):
			return False
		match = re.match(regexp, self.code[self.position])
		return match.string if match else False

	def _take_while(self, regexp):
		ret = ''
		regexp = re.compile(regexp)
		while self.position < len(self.code) and regexp.match(self.code[self.position]):
			ret += self.code[self.position]
			self.position += 1
		return ret

	def _expect_identifier(self):
		ident_start = self._is_next_char(r'[A-Za-z_]')
		if not ident_start:
			raise SyntaxError("Expected identifier")
		ident = self._take_while(r'[A-Za-z0-9_\$#\-\.]')
		return ident

	def _expect_number(self):
		number = self._take_while(r'[0-9]')
		return int(number)

	def _is_next(self, what):
		pos = self.position
		for i in range(len(what)):
			if pos >= len(self.code) or self.code[pos] != what[i]:
				return False
			pos += 1
		return True

	def _expect(self, what):
		for i in range(len(what)):
			if self.position >= len(self.code):
				raise SyntaxError("Expected %s, end of file reached" % what)
			if self.code[self.position] != what[i]:
				raise SyntaxError("Expected %s" % what)
			self.position += 1
		return what

	def _goto_next_line(self):
		while self.position < len(self.code) and self.code[self.position] != '\n':
			self.position += 1
		self.position += 1

	def _skip_whitespace(self):
		while True:
			self._take_while(r'\s')
			# Skip comments too
			if self._is_next('--'):
				self._goto_next_line()
				continue
			break
