#!/usr/bin/env python2
# coding=latin1
# Updated: 19.2.14 - Jussi Lahtinen

import argparse
import sys
import string
import re
import math
import os
import subprocess
import copy
from multiprocessing import Process, Pipe, Queue
import os
from os.path import join, abspath
import time
import shutil
from collections import defaultdict
import random
import datetime
import shlex
import ctypes
#import win32process # n�it� tarvitaan windowsin muistink�yt�n monitorointiin
#import win32api
#import win32con
import decode_smv_definitions


### INPUT:
	# usage: algorithm_revised.py [-h] [--logname LOGNAME] [--specfile SPECFILE]
	#		    [--spec SPEC]
	#		  	model_main_file
### TOIMINTA:
	# tarkastaa mallilla annetun ehdon k�ytt�en hyv�ksi kompositionaalisuutta ja tietty� algoritmia
	# Jos on annettu SPECFILE parametri niin mallilla tarkastetaan siin� listatut ehdot
	# Jos SPECFILEa ei ole annettu, tarkastetaan SPEC -parametrin ehto.
	# Jos t�t�k��n ei ole annettu, katsotaan mit� ehtoja on annettu mallin p��tiedostossa
	# Mallin moduulirakenne on annotoitu mallin tiedostoon model_main_file

### OUTPUT:
	# True-jos malli on tosi, ja vastaesimerkki jos ep�tosi. Jos logmode on p��ll� algoritmissa niin, tallennetaan yleinen lokitiedosto
	# johon tulee kooste joka ehdosta, sek� jokaista ehtoa kohden oma loki, jossa on kuvattu verifioinnin kulku. Lis�ksi tallennetaan
	# kaikki mallit, NuSMV-kutsut ja outputit. Kirjataan my�s ajoajat, mallin kokoonpanot, k�ytetyt iteraatiot, ym.

### ESIMERKKI-ajo:
# algorithm_revised.py --specfile ehdot.txt modeldirectory

####
## Luokkien m��rittelyt:
#####

# Lokeja varten luokka johon tallennetaan tietoa ajoista.
# tulostaa kahteen eri lokiin:
# 	printPropertyVerificationLog tallentaa yhden ehdon tapauksessa verifioinnin kulun
#	printStatisticsLog tallentaa yleiset tilastotiedot ehdosta.
class Stats:
	def __init__(self):
		self.modchecktimes = []
		self.refinementtimes = []
		self.refinementminimizationtimes = []
		self.checksperrefinementminimization = []
		self.checksperrefinementminimizationhistory = []
		self.refstyle = ""
		self.result = ""
		self.totalelapsed = 0
		self.specification = ""
		self.iteration  = 0
		self.configuration = []
		self.procedure = []
		self.parallelwinners = []
		self.refinementchecks = 0
		self.minimizationchecks = 0
		self.prooffrom = ""
		self.modpath = ""
	def addRefinementCheck(self):
		self.refinementchecks = self.refinementchecks +1
	def addMinimizationCheck(self):
		self.minimizationchecks = self.minimizationchecks +1
	def addFastest(self, algorithm):
		self.parallelwinners.append(algorithm)
	def addToPropertyVerificationLog(self, string):
		self.procedure.append(string)
	def newModelCheckingTime(self, time):
		self.modchecktimes.append(time)
	def newRefinementTime(self, time):
		self.refinementtimes.append(time)
	def newRefinementMINTime(self, time):
		self.refinementminimizationtimes.append(time)
	def newRefinementMINcheckfigure(self, checks, inhistory):
		self.checksperrefinementminimization.append(checks)
		self.checksperrefinementminimizationhistory.append(inhistory)
	def addResult(self, booleanresult, elapsed, iter, config):
		self.result = booleanresult
		self.totalelapsed = elapsed
		self.iteration = iter
		self.configuration = config
	def addModelPath(self, path):
		self.modpath = path
	def addSpecification(self, spec):
		self.specification = spec
	def printPropertyVerificationLog(self, logfile):
		log = open(logfile, 'a')
		for line in self.procedure:
			print >> log, line
		log.close()
	def printStatisticsLog(self, logfile):
		log = open(logfile, 'a')
		print >> log, "--------------------------------"
		print >> log, " Log from ", datetime.datetime.now()
		print >> log, "--------------------------------"
		print >> log, "Model path:", self.modpath
		print >> log, "Specification:\t", self.specification
		print >> log, "Result:\t", self.result
		print >> log, "If true, the proof was found in:", self.prooffrom
		print >> log, "In ", str(self.iteration), " iterations."
		print >> log, "Final configuration (", len(self.configuration), ") modules:"
		for m in self.configuration:
			print >> log, "\t", m.name,
		print >> log, ""
		print >> log, "Info:"
		print >> log, "\tThe parallel model checking phase was solved first by:"
		for k in range(0, len(self.parallelwinners)):
			print >> log, "\t", self.parallelwinners[k] + " in iteration ", k+1
		print >> log
		print >> log, "\tNew preliminary refinements (expansion phase) created and checked for feasibility: ", self.refinementchecks
		print >> log, "\tRefinement minimizations created and checked: ", self.minimizationchecks
		print >> log
		print >> log, "\tRefinement minimization:\t", self.refstyle
		print >> log, "\tElapsed time:\t", self.totalelapsed
		mctime = 0
		counter = 1
		for x in self.modchecktimes:
			print >> log, "\t\t*** Time spent model checking in iteration ", counter, ":", x
			counter = counter+1
			mctime = mctime + x
		print >> log, "\t*** Total time spent model checking :", mctime
		cemintime = 0
		counter = 1
		for x in self.refinementtimes:
			print >> log, "\t\t*** Time spent in preliminary refinement on iteration ", counter, ":", x
			counter = counter+1
			cemintime = cemintime + x
		print >> log, "\t*** Total time spent checking preliminary refinements :", cemintime
		cemintime = 0
		checks = 0
		hchecks = 0
		counter = 1
		for x in self.refinementminimizationtimes:
			print >> log, "\t\t*** Time spent in refinement minimization on iteration ", counter, ":", x
			counter = counter+1
			cemintime = cemintime + x
		for x in self.checksperrefinementminimization:
			checks = checks + x
		for x in self.checksperrefinementminimizationhistory:
			hchecks = hchecks + x
		print >> log, "\t*** Total time spent minimizing refinements :", cemintime, ". Total of ", checks, " checks performed. Checks skipped because of cache: ",hchecks
		log.close()
	def printStats(self):
		mctime = 0
		for x in self.modchecktimes:
			mctime = mctime + x
		print "*** Time spent model checking :", mctime
		cemintime = 0
		for x in self.refinementtimes:
			cemintime = cemintime + x
		print "*** Time spent creating new refinements :", cemintime
		cemintime = 0
		checks = 0
		hchecks = 0
		for x in self.refinementminimizationtimes:
			cemintime = cemintime + x
		for x in self.checksperrefinementminimization:
			checks = checks + x
		for x in self.checksperrefinementminimizationhistory:
			hchecks = hchecks + x
		print "*** Time spent minimizing the refinements :", cemintime, ". Total of ", checks, " checks performed, ", hchecks, " checks could be skipped because of the cache."

# Tietorakenne vastaesimerkeiss� olevien variable assignmenttien tallentamiseen
# esim. var1 = TRUE
class Assignment:
	def __init__(self, var, value):
		self.variable = var
		self.value = value
	def printAssignment(self):
		print self.variable , " = ", self.value
	def __str__(self):
		return str(self.variable) + " = " + self.value
	def __repr__(self):
		return str(self)

# Luokka vastaesimerkkien tai muiden tracejen tallentamiseen.
# Trace koostuu listasta Assignmentteja, jotka ovat siis variable assignmentteja.
# Listan tilat ovat tracen eri aika-askeleita. Indeksill� 0 on alkutila jne.
# Tracen yhteyteen tallennetaan my�s XML-esitys tracesta
class Trace:
	def __init__(self, file):
		self.states = [] # lista tiloista, jokainen tila on lista assignmentteja, jotka ovat pareja (input, arvo)
		self.code = []
		self.filename = file 
	def  addNewState(self, stateclause):
		self.states.append(stateclause)
	def getFilename(self):
		return self.filename	
	def getLength(self):
		# 
		return len(self.states)
	# Poistetaan yhden muuttujan arvo tietylt� ajanhetkelt�
	#def removeAssignment(self, time, muuttuja):
	#	for assignment in self.states[time]:
	#		if (muuttuja == assignment.variable):
	#			# poistetaan
	#			self.states[time].remove(assignment)
	#			break
	#def getAssignments(self, time):
	#	return self.states[time]
	#def getStates(self):
	#	return self.states
	#def setStates(self, newstates):
	#	self.states = newstates
	# onko tracessa t�m�n nimist� muuttujaa
	#def includes(self, var):
	#	for s in self.states:
	#		for assignment in s:
	#			if (assignment.variable == var):
	#				return True
	#	return False
	# Lukee mihin muuttujiin viitataan tracessa ajanhetkell� 'time'
	# K�y l�pi n�m� muuttujat ja ne moduulit joilta n�iden muuttujien arvot saadaan (Inputin kentt� frommodule)
	# palauttaa n�iden moduulien nimet listana.
	#def getRelevantModulesAt(self, time):
	#	modulenames = []
	#	for assignment in self.states[time]:
	#		modname = assignment.variable.frommodule
	#		if (not (modname in modulenames)):
	#			modulenames.append(modname)
	#	return modulenames
	
	def storetrace(self, tulosterivit):
		self.code = tulosterivit

	# minimoidaan XML-data traceen tallennettujen arvojen perusteella (= muut arvot pois)
	# Eli XML-trace voi olla esim. 10 tilan pituinen. Jos halutaan ottaa prefix t�st� tracesta
	# niin ensin lyhennet��n states-listaa, jonka j�lkeen muokataan XML-koodi vastaamaan
	# t�t� prefixi� kutsumalla t�t� funktiota.
	# Lis�ksi poistetaan XML-koodista ne variable assignmentit, joita ei ole tracessa (minimoitaessa poistettu)
	#def minimizeXMLcode(self):
	#	statenumber = -1 # indeksi 0 on ensimm�inen tila relevant_path -taulukossa
		# k�yd��n vanhaa tracea l�pi:
	#	newcode = []
	#	skipstates = 0
	#	for line in self.XMLcode:
	#		stripline = line.strip()
	#		# jos Tracessa on v�hemm�n tiloja kuin mit� XML-koodissa (ollaan tekem�ss� vastaesimerkist� prefixi�)
	#		# niin ei oteta mukaan ylim��r�isi� tiloja.
	#		if (statenumber == (len(self.states))): # ollaan viimeisest� seuraavassa tilassa (eli t�st� eteenp�in tiloja ei oteta mukaan)
	#			skipstates = 1
	#		# kopioidaan yleiset rivit
	#		# p�ivitet��n miss� tilassa menn��n
	#		# jos state-rivi niin tsekataan relevant_path
	#		if stripline.startswith('<state'):
	#			if (skipstates == 1):
	#				continue
	#			statenumber = statenumber +1
	#			if (statenumber == (len(self.states))): # sen vuoksi t�m� varmistus, ett� <state>-rivik��n ei tulisi trace-tiedostoon
	#				skipstates = 1
	#				continue
	#			newcode.append(line)
	#			continue
	#
	#		if stripline.startswith('<node'):
	#			if (skipstates == 1):
	#				continue
	#		if stripline.startswith('</node'):
	#			if (skipstates == 1):
	#				continue
	#		if stripline.startswith('</state'):
	#			if (skipstates == 1):
	#				continue
	#		if stripline.startswith('<value'):
	#			if (skipstates == 1):
	#				continue
	#			# selvitet��n rivill� oleva muuttuja:
	#			tag1 = line.find('="') + 2	# mist� muuttujannimi alkaa
	#			tag2 = line.find('">')	# mihin muuttujannimi loppuu
	#			var = line[tag1:tag2]
#
	#			# k�yd��n l�pi states-listan assignmentit t�ll� ajanhetkell�
	#			# otetaan XML-koodiin mukaan vain ne variable assignmentit, jotka on mukana minimoidussa tracessa
	#			for assignment in self.states[statenumber]:
	#				#jos t�ss� k�sitell��n samaa muuttujaa kuin vastaesimerkin rivill� "line", s�ilytet��n rivi vastaesimerkiss�
	#				rel_var = assignment.variable.getName()	# mik� muuttuja on kyseess�
	#				if (var == rel_var):	# muuttuja oli joku relevanteista (t�ll� ajanhetkell�)
	#					newcode.append(line)
	#					continue
	#			# nyt on k�yty kaikki relevantit l�pi, ja lis�tty rivi jos se on tarpeellinen
	#			continue
			#jokainen muu rivi kirjoitetaan uuteen traceen
	#		newcode.append(line)
	#	self.XMLcode = newcode	#p�ivitet��n XML-koodi

	def printTrace(self):
		c = 0
		for s in self.states:
			c= c+1
			print "State ", c
			for v in s:
				v.printAssignment()

# Luokka input-muuttujille. Muuttujista s�ilytet��n nimen lis�ksi tieto siit� mist� moduulista sen arvo saadaan (frommodule)
# sek� se miss� moduulissa input k�sitell��n (tomodule)
# sek� inputin mahdolliset arvot
class Input:
	def __init__(self, name, frommodulename, tomodulename): #, type):
		self.variablename = name # muuttujan nimi
		self.frommodule = frommodulename #milt� moduulilta l�htee/ saadaan
		self.tomodule = tomodulename # mille moduulille t�m� input tulee
		#self.type = type # mitk� ovat muuttujan mahdolliset arvot, muodossa "{TRUE, FALSE}"
	def getName(self):
		return self.variablename
	# testaa onko annetussa joukossa set joku alkio jonka kent�t vastaavat t�t� input-muuttujaa
	def isInSet(self, set):
		for input2 in set:
			if ((self.variablename == input2.variablename) & (self.frommodule == input2.frommodule)): #&(self.type == input2.type)):
				return True
		return False
	def printInput(self):
		print "\tVariable name: ", self.variablename #, ": ", self.type
		print "\tModule that has variable as output: ", self.frommodule
		print "\tModule that has variable as input: ", self.tomodule
	def __str__(self):
		return self.variablename
	def __repr__(self):
		return str(self)

# Tietorakenne outputarvoille. Nimi ja moduuli jolta output l�htee tallennetaan.
class Output:
	def __init__(self, name, frommodulename):
		self.variablename = name # muuttujan nimi
		self.frommodule = frommodulename #milt� moduulilta l�htee/ saadaan
	def printOutput(self):
		print "\tVariable name: ", self.variablename
		#print "\tModule that has variable as output: ", self.frommodule

# Tietorakenne moduuleille.
# Kenttin�: lista inputeista, lista outputeista, tiedostonimi, sek� interfacetiedoston nimi
class Module:
	def __init__(self, name, filename, dummy):
		self.name = name
		self.inputs = []
		self.outputs = []
		self.filename = filename
		self.dummyfilename = dummy
	def addInput(self, input):
		self.inputs.append(input)
	def addOutput(self, output):
		self.outputs.append(output)
	def getName(self):
		return self.name
	# testaa onko annetussa joukossa set joku alkio jonka kent�t vastaavat t�t� moduulia
	def isInSet(self, set):
		for input in set:
			if (self.name == input.name):
				return True
		return False
	def getExpansion(self, modules):
		expansion = []
		for i in self.inputs:
			for m in modules:
				if (m.name == i.frommodule):
					if (not (m.isInSet(expansion))):
						expansion.append(m)
		return expansion

	def printModule(self):
		print "Module ", self.name
		print "\t Filename: ", self.filename
		print "\t Dummy file: ", self.dummyfilename
		print "Module's inputs:"
		for i in self.inputs:
			i.printInput()
		print "Module's outputs:"
		for o in self.outputs:
			o.printOutput()

# Luokka mallin rakenteen hallintaan.
# luokassa on tallennettuna se moduulien konfiguraatio (abstraktiotaso) jota parhaillaan k�sitell��n.
# Lis�ksi on tallennettu tietoja joita tarvitaan mallintarkastukseen (tiedostonimet, k�sitelt�v� ehto)
class ModelStructure:
	# Avataan tiedosto, jossa on kaikki tarvittava tieto mallista
	# Luetaan tiedot luokan instanssin kenttiin
	def __init__(self, spec=None):
		self.modules = [] 			# All modules
		self.currentconfiguration = []	# Mallissa default-muodossa olevat moduulit
								# listan alkiot Module-instansseja
								# jos ei listassa, k�ytet��n dummy-versiota
		self.modelfilename=""
		self.functionblockfile = "" 		# toimilohkojen kooditiedosto
		
		self.logmode = True
		self.iteration = 0
		self.stats = Stats()
		
		self.tracetype = '' #jos tulee aiger-vastaesimerkki niin voidaan merkit� se t�h�n 'aiger'
		
		self.specification = spec.strip(';')	
		# TODO: tsekkaa sulutus (L2S on tarkka)
		
		
		# m��ritell��n speksin tyypin perusteella
		self.isLTLspec = False
		self.isInvarspec = False
		if (self.specification.startswith('INVARSPEC')):
			self.isInvarspec = True
		else:
			if (self.specification.startswith('LTLSPEC')):
				self.isLTLspec = True
			else:	# ei kumpikaan speksi (?)
				print "Specification has to be either INVARSPEC or LTLSPEC"
				sys.exit(1)		
		
		self.stats.addSpecification(self.specification)	# p�ivitet��n statistiikkaa ker��v�n luokan speksi

		# K�ytetyt hakemistot:
		self.logdirectory = logdir					# m��ritell��n mainissa
		self.modelpath = os.path.dirname(os.path.realpath(args.model_main_file)) # hakemisto jossa mallin main-file on
		self.stats.addModelPath(self.modelpath)
		self.runningdirectory = 'temp'
		try:
			if (not os.path.exists(self.runningdirectory)):
				os.makedirs(self.runningdirectory)
				os.chmod(self.runningdirectory, 0o755)
		except:
			print "Could not create running directory"
			sys.exit(1)
		# K�ytett�vien tiedostojen polut/tiedostonimet:
		self.tempname =  os.path.join(self.runningdirectory, 'temp.smv')
		#self.dependencydata = os.path.join(self.modelpath, "depdata.txt")

		self.logged_time=time.time()
		self.modelfilename =  args.model_main_file 	# parametrina saatu mallin main-file
		try:
			inputfile = open(self.modelfilename)
			lines = inputfile.readlines()
			inputfile.close()
		except IOError:
			print "Could not read model data file"
			sys.exit(1)

		# Reading the model main-file:
		currentmodule = ""
		varmode = 0
		continued_declaration = ""
		declaration_not_finished = False
		check_declaration = False
		for l in lines:		# tiedoston rivit l�pi
			if (l.strip() == ""):	
				continue
			strip_l = l.strip()
			split_l = strip_l.split()
			if (len(split_l) > 1):		# sellaiset rivit joilla useampi "sana"
				if ((split_l[0] == "--") & (split_l[1] == "module")):		# moduulin m��rittelyrivi on muotoa "-- module <nimi> : <tiedostonimi>  
					separate = strip_l.split(':')					# erotteleva merkki on ":"
					if (len(separate) < 2):						# oltava jako kahteen 
						print "Module declaration error 1! Error line: ", strip_l
						sys.exit(1)
					firstpart = separate[0].split()
					if (len(firstpart) < 3):			# ensimm�inen osa koostuu kolmesta osasta " -- module <nimi>"
						print "Module declaration error 2!  Error line: ", strip_l
						sys.exit(1)
					modname = firstpart[2].strip()	# luetaan moduulin nimi
					modfilename =  separate[1].strip()	
					# modinterfacename = separate[2].strip()
					modinterfacename = modfilename.replace('.smv','_interface.smv') # interface-moduulin on oltava t�m�n niminen

					# yhdistet��n mallin hakemistonimeen
					modfilename2 = os.path.join(self.modelpath, modfilename)
					modinterfacename2 = os.path.join(self.modelpath, modinterfacename)
					mod = Module(modname, modfilename2, modinterfacename2)
					self.modules.append(mod)
					currentmodule = mod
					
					# Avataan moduulin interfacemoduuli ja luetaan sielt� moduulin outputit:
					interfacefile = open(modinterfacename2) 
					interlines = interfacefile.readlines()
					interfacefile.close()
					
					il_varmode = 0
					for il in interlines:	# k�yd��n interfacemoduulin rivit l�pi:
						ils = il.strip()
						#print ils
						if (ils == ""):
							continue
						if (ils.startswith('VAR')):
							il_varmode = 1
							continue
						if (ils.startswith('DEFINE')):
							il_varmode = 1		# jossain moduuleissa voi olla interface-muuttujia my�s DEFINE-osasssa
							continue
						if (ils.startswith('ASSIGN')):
							il_varmode = 0
							continue
						if (ils.startswith('VAR')):
							il_varmode = 0
							continue
						if (ils.startswith('--')):
							continue
						if (il_varmode == 1):	# jos ollaan VAR -m��rittelyosiossa
							outputvar = ils.split(':')[0].strip()	# luetaan muuttujan nimi
							outputvarstruct = Output(outputvar, currentmodule.getName()) # luodaan uusi Output
							currentmodule.addOutput(outputvarstruct)	# kytket��n Output oikeaan moduuliin.
					continue
				if ((split_l[0] == "--") & (split_l[1] == "library")):
					print "library:", split_l[2]
					fbfilename = os.path.join(self.modelpath, split_l[2])
					#absfbfilename = os.path.join(self.modelpath, files[1])
					self.functionblockfile = fbfilename
					continue
			if (strip_l.startswith('VAR')):
				varmode = 1
				continue
			if (strip_l.startswith('DEFINE')):
				varmode = 0
				continue
			if (strip_l.startswith('ASSIGN')):
				varmode = 0
				continue
			if (varmode == 1):
				# Jos edellisill� riveill� alkanut m��rittely on kesken (jakaantuu usealle riville):
				if declaration_not_finished:
					if (strip_l.endswith(';')): # Jos p��ttyy nyt
						continued_declaration = continued_declaration +  " " + strip_l # yhdistet��n rivit
						declaration_not_finished = False	# m��rittely ei ole en�� kesken
						check_declaration = True	# M��rittely on kokonainen ja voidaan parsia 
					else:		# ei p��ty viel�k��n
						continued_declaration = continued_declaration +  " " + strip_l # otetaan rivi talteen
						continue # ei p��ttynyt, menn��n seuraavalle riville
				else: # edellisill� riveill� alkanut m��rittely ei ole kesken 
					# tarkastetaan alkaako rivill� uuden moduulin m��rittely
					for m in self.modules:
						if (split_l[0] == m.getName()): # rivill� on moduulin m m��rittely
							# read module inputs
							continued_declaration = strip_l
							declaration_not_finished = False
							if (not strip_l.endswith(';')):
								#print "\n\n several lines in declaration \n\n"
								declaration_not_finished = True
								check_declaration = False
							else: 
								check_declaration = True
							break	# ei tarkasteta muita moduuleita kun on jo l�ytynyt matchi
				# Jos valmis m��rittely rivi on kasassa, parsitaan se:
				if check_declaration:
					check_declaration = False
					brackets = re.compile('\((.*?)\)')	# sulkujen v�liss� oleva osa
					inputit = brackets.search(continued_declaration).group(1).split(',')	# moduulin inputit listana
					for i in inputit:		# k�yd��n inputit l�pi
						ist = i.strip()
						#jos muuttujan nimess� on piste, katsotaan viittaako ensimm�inen osa johonkin moduuleista
						# jos viittaa niin luodaan linkki siihen moduuliin. muussa tapauksessa frommodule on "--FREE--"
						# 
						if ("." in ist):
							modulesearch = re.compile('(.*?)\.')	# ottaa ensimm�isen pisteen vasemmalla puolella olevan osan
							modulepart = modulesearch.search(ist).group(1).strip()
							if modulepart.startswith('!'):		# jos muuttujan yhteydess� on negaatio niin poistetaan se. mit�k�h�n muuta t�ss� pit�isi viel� ottaa huomioon?
								modulepart = modulepart[1:].strip()
							
							# k�yd��n l�pi moduulit ja katsotaan vastaako modulepart jotain n�ist�.
							# jos ei vastaa niin t�m� on vain vapaa muuttuja vaikka tuleekin joltain moduulilta
							matched_module = False
							for m2 in self.modules:
								if (modulepart == m2.getName()):
									#print "MATCH", modulepart
									inputvar = Input(ist, modulepart, m.getName()) #, "")	# luodaan Input
									m.addInput(inputvar)	# kytket��n moduuliin
									matched_module = True
									break # ei k�yd� muita moduuleja l�pi
							if (not matched_module):	# tulkitaan vapaana muuttujana
								#print "No MATCH"
								inputvar = Input(ist, "--FREE--", m.getName()) #, "")
								m.addInput(inputvar)
							continue # next input
						# jos ei ollut pistett� : Vapaa muuttuja lis�t��n
						inputvar = Input(ist, "--FREE--", m.getName())#, "")
						m.addInput(inputvar)
						#inputvar.printInput() #DEBUG
						continue # next input
					#break # jos l�ydettiin matchi moduulin nimeen niin muita ei tarvitse en�� k�yd� l�pi

	# a variable name as input
	# return a module instance that is related to that module
	# meaning that the module that gives the variable as output is returned
	def getRelatedModule(self, varname):
		# k�yd��n l�pi kaikki moduulit ja niiden outputit j�rjestyksess�
		# palautetaan moduuli kun kohdataan ensimm�inen samanniminen muuttujannimi
		for m in self.modules:
			for o in m.outputs:
				comparisonstring = m.getName() + "." + o.variablename
				#print comparisonstring, varname
				if (comparisonstring == varname):
					return m
		# jos ei l�ytynyt, palautetaan tyhj�
		return ""

	# lue ehdossa olevat muuttujat, ja selvit� n�ihin liittyv�t moduulit
	# tallenna currentconfiguration-tietorakenteeseen
	def initializeConfiguration(self):
		specvars = self.parseSpecificationVariables()
		self.currentconfiguration = [] # reset the configuration
		for sv in specvars:
			m = self.getRelatedModule(sv)
			if (m == ""): # saatiin tyhj� (input muuttuja)
				continue
			if (not (m in self.currentconfiguration)):	# lis�t��n moduuli vain jos se ei jo ole configuraatiossa
				self.currentconfiguration.append(m)
		return

	#  rakenna malli jossa n�m� moduulit currentconfigurationin mukaisesti. Tulos temp.smv
	# mallintarkasta t�m� malli
	# Ota mahdollinen vastaesimerkki talteen
	# logdir on hakemisto johon lokit  ker�t��n
	def modelCheckCurrentConfiguration(self, logdir):
		# generoi mallitiedosto:
		self.generateModel()	
		self.iteration += 1
		if (self.logmode):
			shutil.copyfile(self.tempname,  os.path.join(logdir, "Iteration_" + str(self.iteration) + "_Model_file.smv"))
		# Koska ei ole j�rkev�� tehd� reduktiota useaan kertaan 

		# Clean any previous trace files so all we see afterwards are fresh ones
		for f in os.listdir(self.runningdirectory):
			if f.endswith("_trace.txt"):
				os.unlink(join(self.runningdirectory, f))
		# Run algorithms in parallel
		mcresult, algorithm = self.runAlgorithmsInParallel()

		if (self.logmode):
			self.stats.addToPropertyVerificationLog("First complete in iteration"+str(self.iteration)+ ":" + algorithm)
			self.stats.addFastest(algorithm)
		if (mcresult == "true"):
			self.stats.prooffrom = "Model Checking phase using "+ algorithm
			return "true", ""
		else:
			tracefile = join(self.runningdirectory, algorithm + '_trace.txt')
			trace = self.readModelCheckingResult(tracefile)
			if (self.logmode):
				shutil.copyfile(tracefile, join(logdir, "Iteration_" + str(self.iteration) + "_" + algorithm + "_counterexample.txt"))
				# jos aiger-ce niin k��nnet��n XML-muotoon. tracefile abczz.aig output
				# jo siirret��n my�s se trace kansioon				
				if (self.tracetype == 'aiger'):	# HUOM! T�ss� oletetaan ett� malli on tiedostossa abczz.aig ja ett� sielt� l�ytyy mappaus muuttujiin!
					translateCE(tracefile,
					            join(self.runningdirectory, algorithm + '.aig'),
					            join(self.runningdirectory, 'flat-orig.smv'),
					            join(self.runningdirectory, 'translated_trace.txt'))
					shutil.copyfile(join(self.runningdirectory, 'translated_trace.txt'), join(logdir, "Iteration_" + str(self.iteration) + "_" + algorithm + "_counterexample_translated.txt"))
				
				

			return "false", trace

	# rakenna malli jossa n�m� moduulit currentconfigurationin mukaisesti. Tulos temp.smv
	def generateModel(self):
		# Avataan temp.smv kirjoitusta varten

		tempfile = open(self.tempname, 'w')
		# kirjoitetaan p��malli t�h�n tiedostoon

		main = open(self.modelfilename)
		mainlines = main.readlines()
		main.close()
		speccont = 0
		inmain=False
		specwritten = False
		for l in mainlines:	# oletetaan ett� jokainen ehto omalla rivill� + poistetaan ne ehdot kokonaan joita ei tarvita (h�iritsee L2S:n toimintaa)
			if (l.strip().startswith('INVARSPEC')):	 # Kommentoidaan pois ne rivit joilla on joku ehto ettei se h�iritse algoritmin ajamista.
				continue	# ei tehd�k��n mit��n				
				#print >> tempfile, "--" + l,
				#if (l.strip().endswith(';')):
				#	continue
				#else: # speksi jatkuu
				#	speccont = 1
				#	continue
			#if (speccont == 1):
			#	print >> tempfile, "--" + l,
			#	if l.strip().endswith(';'): # speksi ei jatku seuraavalla rivill�
			#		speccont = 0
			#		continue
			if (l.strip().startswith('LTLSPEC')):
				continue				
				#print >> tempfile, "--" + l,
				#if (l.strip().endswith(';')):
				#	continue
				#else: # speksi jatkuu
				#	speccont = 1
				#	continue
			if (l.strip().startswith('CTLSPEC')):
				continue
				#print >> tempfile, "--" + l,
				#if (l.strip().endswith(';')):
				#	continue
				#else: # speksi jatkuu
				#	speccont = 1
				#	continue
			if (inmain and l.strip().startswith('MODULE')): # jos main-tiedostossa on muita moduuleja niin laitetaan speksi mainin j�lkeen
				print >> tempfile, self.specification
				print >> tempfile, l,
				inmain = False
				specwritten = True
				continue
			if (l.strip().startswith('MODULE') and ('main' in l.strip())):
				inmain = True
			print >> tempfile, l,

		# kirjoitetaan t�h�n v�liin tarkastettava ehto
		if not specwritten:
			print >> tempfile, self.specification

		# k�yd��n kaikki moduulit l�pi ja kirjoitetaan oleellinen version temp.smv:hen
		for m in self.modules:
			mod = ""
			if (m in self.currentconfiguration):
				mod = open(m.filename)
			else:
				mod = open(m.dummyfilename)
			modlines = mod.readlines()
			mod.close()
			for l in modlines:
				print >> tempfile, l,

		# tulostetaan toimilohkojen m��ritelm�t my�s
		# 
		try:
			fb  = open(self.functionblockfile)
			fblines = fb.readlines()
			fb.close()
			for l in fblines:
				print >> tempfile, l,
			tempfile.close()
			return ""
		except:
			print "Did not find function block library"
			pass

	# Run in parallel all the algorithms in the algorithm dir, return when any of them comes up with an answer
	def runAlgorithmsInParallel(self):
		processes = []
		algorithm_dir = liveness_dir if self.isLTLspec else algo_dir	# Jos vaatimus on LTL-vaatimus k�ytet��n liveness-skriptej�, muuten invarianteille tarkoitettuja
		for algorithm in os.listdir(algorithm_dir):
			command = ["zsh", abspath(join(algorithm_dir,algorithm)), abspath(self.tempname)]
			outfile = join(self.runningdirectory, algorithm + ".out")
			errfile = join(self.runningdirectory, algorithm + ".err")
			processes.append(
				(algorithm,
				 subprocess.Popen(
					 command,
					 stdout = open(outfile, "w"), stderr = open(errfile, "w"),
					 cwd = self.runningdirectory),
				 outfile, errfile))

		while processes:
			time.sleep(0.1)
			for i in range(len(processes)):
				p = processes[i]
				if p[1].poll() != None:
					del(processes[i])
					p[1].communicate()
					if p[1].returncode != 0:
						print "Command " + p[0] + " failed:"
						for f in p[2:4]:
							for line in open(f):
								print line
						exit(1)

					resultaiger = reduce(lambda a, b: a or b,
							[re.search('Property (PROVED|FAILED)', l) for l in open(p[2])])				
					result = reduce(lambda a, b: a or b,
							[re.search('is (true|false)', l) for l in open(p[2])])
					algorithm = os.path.splitext(p[0])[0]
					if result or resultaiger:
						for p in processes:
							try:
								p[1].terminate()
							except:
								pass
						if result: 						
							return result.group(1), algorithm
						if resultaiger:
							if resultaiger.group(1) == 'PROVED':
								return 'true', algorithm
							if resultaiger.group(1) == 'FAILED':
								return 'false', algorithm
							else:
								print "Problem in determining result of aiger checker output"
								sys.exit(1)
					else:
						print "Warning!", p[0], "did not give a result."
					break
		assert False, "No result from any model checker!"

	# Refinement minimization -askeleen suorittava funktio. Luo mallin konfiguraatioita ja testaa niiden hyvyyden k-induktiolla k�ytt�m�ll� alkuper�isen
	# vastaesimerkin pituutta boundina. Palauttaa pienimm�n l�ytyneen refinementin joka toimii. Jos jokin konfiguraation tuottaa todistuksen k-induktiolla,
	#keskeytet��n ja palautetaan se kokoonpano.
	# Kokoonpanojen generointiin k�ytet��n delta debuggingia. Muuten samanlainen kuin tavallinen delta, mutta t�ss� lis�ksi tarkastetaan onko alijoukossa sellaisia moduuleita joita ei voi saavuttaa
	# moduulijoukon ytimest� (basemodules), eli niist� moduuleista jotka olivat mukana ennen abstraction refinementtia. Jos t�llaisia
	# saavuttamattomia moduuleita on, ne poistetaan alijoukosta, ja silloin t�m� alijoukko mahdollisesti mappautuu jollekin jo tarkistetulle
	# alijoukolle, ja t�m� tieto l�ytyy sitten historyofsubsets-rakenteesta.
	# locks: Joukko Refinementissa olevia moduuleita
	# basemodules: mallin konfiguraatioon jo kuuluvat moduulit joita ei t�ss� minimoida
	# logdir: lokidatan hakemisto
	# counterexample: vastaesimerkki (pituus tarvitaan eri konfiguraatioiden testaamiseen
	# palauttaa kaksi arvoa:
	#	minimoidun konfiguraation
	# 	"proof"-merkkijonon, jos annettu konfiguraatio on my�s antanut todistuksen
	def refinementMinimization(self, locks, basemodules, logdir, counterexample):
		n= 2 # algoritmin granulariteetti
		restart = 0
		subsetchecks = 0
		foundinhistory = 0
		historyofsubsets = []
		minimization_candidate = 1
		while (True): #delta debugging p��looppi
			if (len(locks) == 1):
				#print "Only one module left, cannot minimize further."
				break
			if (len(locks) == 0):
				#print "No items left. Cannot minimize."
				break
			random.shuffle(locks) # randomoidaan joka iteraatiolla
			subsets  = self.getSets(locks, n)		# generoidaan alijoukot
			complements = self.getComplements(locks, subsets)	# ja n�iden komplementit

			# k�yd��n setit l�pi
			for lockset in subsets:
				subsetchecks = subsetchecks +1

				###  REMOVE UNREACHABLE MODULES from the lockset:
				reachablelockset = self.getReachableNewModules(basemodules, lockset)

				if (reachablelockset in historyofsubsets):
					#Subset already checked. Moving on...
					foundinhistory = foundinhistory +1
					continue

				logtag = "minimization_candidate_"+ str(minimization_candidate)
				# testattava konfiguraatio lokiin:
				if (self.logmode):
					self.stats.addMinimizationCheck()
					self.stats.addToPropertyVerificationLog("Refinement minimization candidate " + str(minimization_candidate) + ":")
					for l in reachablelockset:
						self.stats.addToPropertyVerificationLog(l.name)

				minimization_candidate = minimization_candidate +1

				# tarkistetaan onko t�m� konfiguraatio hyv� refinement:
				self.currentconfiguration = []
				testconfiguration = []
				for x in basemodules:
					testconfiguration.append(x)
				for x in reachablelockset:
					testconfiguration.append(x)
				for m in testconfiguration:
					self.currentconfiguration.append(m)
				refinementgood, proofindicator = self.isRefinementGood(counterexample.getLength(), logtag, logdir)

				# vastauksen mukaan luodaan uudet setit
				# jos refinement on hyv�, jatketaan minimoimalla sit� , granularity = 2
				if (not refinementgood):
					historyofsubsets.append(reachablelockset)
				if (refinementgood):
					if (proofindicator == "proof"):
						print "Subset proved the property!"
						locks = []
						for k in reachablelockset:
							locks.append(k)
						self.stats.prooffrom = "Refinement minimization candidate number "+ str(minimization_candidate)
						return locks, "proof"
					print "\t Subset satisfiable! Restarting delta with the subset."
					print "Subset was:"
					for k in reachablelockset:
						print "\t", k.name

					locks = []
					for k in reachablelockset:
						locks.append(k)
					n=2
					restart = 1
					break
			if (restart == 1): # jos l�ydettiin pienempi setti, ei k�yd� komplementteja l�pi vaan aloitetaan loopin alusta
				#print "Restarting,  n=", n
				restart = 0
				continue
			for lockset in complements:
				subsetchecks = subsetchecks +1
				#Checking complement set of items
				###  REMOVE UNREACHABLE MODULES from the lockset:
				reachablelockset = self.getReachableNewModules(basemodules, lockset)

				if (reachablelockset in historyofsubsets):
					#Subset already checked. Moving on..."
					foundinhistory = foundinhistory +1
					continue

				logtag = "minimization_candidate_"+ str(minimization_candidate)
				minimization_candidate = minimization_candidate +1
				# testikonfiguraatio lokiin:
				if (self.logmode):
					self.stats.addToPropertyVerificationLog("Refinement minimization candidate " + str(minimization_candidate) + ":")
					for l in reachablelockset:
						self.stats.addToPropertyVerificationLog(l.name)

				# tarkistetaan konfiguraatio:
				self.currentconfiguration = []
				testconfiguration = []
				for x in basemodules:
					testconfiguration.append(x)
				for x in reachablelockset:
					testconfiguration.append(x)
				for m in testconfiguration:
					self.currentconfiguration.append(m)
				refinementgood, proofindicator = self.isRefinementGood(counterexample.getLength(), logtag, logdir)

				# jos komplementti on hyv� refinement, jatketaan sill�, granularity = max(n-1, 2)
				if (not refinementgood):
					historyofsubsets.append(reachablelockset)
				if (refinementgood):
					if (proofindicator == "proof"):
						print "Subset proved the property!"
						locks = []
						for k in reachablelockset:
							locks.append(k)
						self.stats.prooffrom = "Refinement minimization candidate number "+ str(minimization_candidate)
						return locks, "proof"
					print "\t Complement satisfiable! Restarting delta with the complement."
					print "Subset was:"
					for k in reachablelockset:
						print "\t", k.name

					locks = []
					for k in reachablelockset:
						locks.append(k)
					n = max(n-1, 2)
					restart  = 1
					break
			if (restart== 1): # jos l�ydettiin pienempi setti aloitetaan loopin alusta
				restart = 0
				continue
			#  kaikki setit ovat sellaisia ett� eiv�t aiheuta virhett� kaikissa tapauksissa, niin, jos granulariteetti on pienempi kuin lukkojen m��r�
			#  kokeillaan uusilla seteill�, granulariteetti = min(lukkojen m��r�, 2n).
			if  (n < len(locks)):
				n = min(len(locks), 2*n)
				#All subsets searched, increasing granularity
				continue
			else: #granulariteetti on jo sama kuin lukkojen m��r�  -  lopetetaan
				#Granularity = nro of locks - end of search
				break
		self.stats.newRefinementMINcheckfigure(subsetchecks, foundinhistory)
		return locks, ""

	# Delta-funktion k�ytt�m� apufunktio joka palauttaa setist� n kappaletta subsettej�
	def getSets(self, set, n):
		l = len(set)
		#print "len = ", l
		subsetl = abs(l / n)
		extra = l - (subsetl *n)
		#print "extra : ", extra
		sets = []
		for i in range(n):
			#print "alku", i*subsetl
			#print (i+1)*subsetl
			subset = set[(i)*subsetl:subsetl*(i+1)]
			sets.append(subset)
		# jos setteihin jako ei mene tasan:
		viimeinen = subsetl*n
		counter = 0
		for i in range(viimeinen, l):
			sets[counter].append(set[i])
			counter = counter+1
			#print "indeksi: ", counter
			#print "alkio:  ", set[i]
		return sets

	# Delta-funktion k�ytt�m� apufunktio joka palauttaa subsettien komplementit suhteessa annettuun settiin
	def getComplements(self, set, subsets):
		complements = []
		for s in subsets:
			c = []
			for x in set:
				c.append(x)
			for item in s:
				#print item
				#print c
				c.remove(item)
			complements.append(c)
		return complements


	def isRefinementGood(self, length, logtag, logdir):
		self.generateModel()	# luodaan malli nykyisen konfiguraation perusteella
		
		algorithm_dir = liveness_dir if self.isLTLspec else algo_dir	# k�ytet��n asianmukaista skripti� liveness / invariant
		command = ["zsh", abspath(join(algorithm_dir, "bmc.sh")), abspath(self.tempname), str(length)]
		outfile = join(self.runningdirectory, "bmc.out")
		errfile = join(self.runningdirectory, "bmc.err")
		process = subprocess.Popen(
			command,
			stdout = open(outfile, "w"), stderr = open(errfile, "w"),
			cwd = self.runningdirectory)
		process.communicate()
		if (process.returncode != 0):
			print "Error: NuSMV could not function"
			print "NuSMV command that failed: " + " ".join(command)
			print "Error message: " + open(errfile).read()
			sys.exit(1)

		#avataan NuSMV:n output
		result_file = open(outfile)
		lines = result_file.readlines()
		result_file.close()

		if ([l for l in lines if re.search('invariant.*is false', l)]):
			# l�ytyi vastaesimerkki, refinement ei ole riitt�v�
			print "Checked refinement is not good enough."
			if (self.logmode):
				self.stats.addToPropertyVerificationLog("Feasibility check result (" + logtag + ": original c-e still feasible")
			return False, join(self.runningdirectory, "bmc_trace.txt")

		if ([l for l in lines if re.search('invariant.*is true', l)]):
			print "Checked refinement is good."
			if (self.logmode):
				self.stats.addToPropertyVerificationLog("Feasibility check result (" + logtag + ": original c-e not feasible, and found a proof for the property.")
			return True, "proof"

		print "Checked refinement is good."
		if (self.logmode):
			self.stats.addToPropertyVerificationLog("Feasibility check result (" + logtag + ": original c-e not feasible.")
		return True, ""

	# luo uusi mallin konfiguraatio jolla
	# annettu vastaesimerkki on mahdoton
	# Palauttaa:
	# 	"no refinement" / "proof" / "refinement ok"	 =	tehtiin refinementtia kunnes ei en�� mahdollista / l�ytyi todistus / l�ydettiin uusi refinement mutta ei todistusta
	def refineConfiguration(self, counterexample, logdir):
		# Laajennusvaihe: lis�t��n nykyisten moduulien naapurit, ajetaan BMC
		# Minimointivaihe: kokeillaan alijoukkoa lis�tyist� moduuleista, ajetaan BMC
		refinementstart = time.time()	# aika alkaa, kuinka kauan kest�� preliminary refinement

		# mitk� n�ist� ovat uusia moduuleita suhteessa aiemmin tarkastettuun konfiguraatioon
		Refinement = [] # moduulit jotka lis�t��n refinementissa
		Current = []
		print "Searching for a new refined configuration of modules:"
		for m in self.currentconfiguration:
			Current.append(m)
		for m in Current:
			neighbormodules = m.getExpansion(self.modules)
			for n in neighbormodules:
				if (not(n.isInSet(Current))):
					if (not(n.isInSet(Refinement))):
						Refinement.append(n)
		
		# jo t�ss� voidaan todeta jos uusia moduuleita ei voida lis�t� ensimm�sess� iteraatiossa. T�ll�in pit�isi 
		# palauttaa counterexample
		if len(Refinement) == 0: # ei lis�tt�vi� moduuleja
			if (self.logmode):
				self.stats.addToPropertyVerificationLog("Initial configuration could not be expanded further.")
			print "No further refinement is possible. A counter-example produced by all relevant modules is found in " , counterexample.getFilename()
			print "BMC-check full-model for full counter-example."
			refinementelapsed = (time.time() -refinementstart)
			self.stats.newRefinementTime(refinementelapsed)
			return "no refinement"
			
		self.currentconfiguration.extend(Refinement)

		print "New candidate refinement is:"
		self.printConfiguration()
		candidate_number = 1
		# laajennetaan moduulikonfiguraatiota kunnes vastaesimerkist� tulee mahdoton
		while (True):
			print "Checking candidate refinement..."
			# kandidaatti lokiin:
			if (self.logmode):
				self.stats.addRefinementCheck()
				self.stats.addToPropertyVerificationLog("Refinement candidate "+str(candidate_number)+ ":")
				for m in self.currentconfiguration:
					self.stats.addToPropertyVerificationLog(m.name)
			# tarkastetaan onko kandidaatti hyv�
			refinementgood, secondparam = self.isRefinementGood(counterexample.getLength(), "refinement_candidate_" +str(candidate_number), logdir)
			if (refinementgood):
				print "The refinement was successful, counter-example is impossible in the candidate configuration"
				if (secondparam == "proof"):
					print "The refinement also proved the property."
					if (self.logmode):
						self.stats.addToPropertyVerificationLog("Refinement candidate "+str(candidate_number)+ " was proved")
						self.stats.prooffrom="Abstraction Refinement (candidate number " + str(candidate_number) + ")"
					return "proof"
				if (self.logmode):
					self.stats.addToPropertyVerificationLog("Refinement candidate "+str(candidate_number)+ " was successful (-> minimizing)")
				break
			# kandidaatti oli huono:
			if (self.logmode):
				self.stats.addToPropertyVerificationLog("Refinement candidate "+str(candidate_number)+ " was not successful")

			candidate_number = candidate_number +1
			print "Counter-example still possible, need further refinement..."
			newRefinementModules = []
			# vastaesimerkki on viel�kin mahdollinen: pit�� lis�t� moduuleita
			for m in Refinement: # kaikki lis�tyt moduulit l�pi
				expandedmodules = m.getExpansion(self.modules) # Laajennetaan riippuvuusgraafin mukaan
				for e in expandedmodules:
					if (not ((e.isInSet(Refinement)) | (e.isInSet(Current)))): # jos x  ei ole konfiguraatiossa
						if (not (e.isInSet(newRefinementModules))): # jos ei jo ole lis�tty t�t� moduulia
							newRefinementModules.append(e) # lis�t��n x
							print "\t Adding new module: ", e.name
			if (not refinementgood): # refinement ei onnistunut
				if (len(newRefinementModules) == 0): # eik� uusia lis�tt�vi� moduuleita:
					if (self.logmode):
						self.stats.addToPropertyVerificationLog("Refinement (candidate "+str(candidate_number) + ") could not be expanded further.")
					print "No further refinement is possible. A counter-example produced by all relevant modules is found in " + secondparam,
					print ". BMC-check full-model for full counter-example."
					refinementelapsed = (time.time() -refinementstart)
					self.stats.newRefinementTime(refinementelapsed)
					# jos ei ole uusia lis�tt�vi� moduuleita ja refinemen oli huono niin ollaan lopussa. ehto on ep�tosi, vastaesimerkki on viimeisest� refinementista saatu vastaesimerkki
					return "no refinement"

			self.currentconfiguration.extend(newRefinementModules)

			#preliminary refinement on p��ttynyt. printataan tulos:
			for n in newRefinementModules:
				Refinement.append(n)
			print "New candidate refinement is:"
			self.printConfiguration()

		refinementelapsed = (time.time() -refinementstart)
		self.stats.newRefinementTime(refinementelapsed)

		# kun l�ytynyt, voidaan etsi� takaisinp�in: mit� moduuleita voitaisiin ottaa pois
		start = time.time()
		print "\n Attempting to minimize refinement through delta debugging."
		Refinement, minimizationproof = self.refinementMinimization(Refinement, Current, logdir, counterexample)
		print "\nRefinement minimization complete."
		if (minimizationproof == "proof"):
			print "A proof was found in delta minimization"
			return "proof"
		elapsed = (time.time() - start)
		self.stats.newRefinementMINTime(elapsed)

		for r in Refinement:
			print "\tAdded in refinement: ", r.name
		newconfiguration = []
		self.currentconfiguration = []
		for x in Current:
			newconfiguration.append(x)
		for x in Refinement:
			newconfiguration.append(x)
		for m in newconfiguration:
			self.currentconfiguration.append(m)
		if (self.logmode):
			self.stats.addToPropertyVerificationLog("Final refinement: ")
			for m in self.currentconfiguration:
				self.stats.addToPropertyVerificationLog(m.name)

		return "refinement ok"


	# DeltaForRefinement-funktion k�ytt�m� apufunktio joka pudottaa moduulijoukosta ne moduulit jotka eiv�t ole saavutettavissa alkuper�isist� moduuleista
	def getReachableNewModules(self, basemodules, newmodules):
		reachablemodules = []
		for m in basemodules:
			reachablemodules.append(m)
		newmodulesadded = 0
		while True:
			for n in newmodules:
				# ei reachable & next to a reachable module --> add, flag
				for m in reachablemodules:
					for i in m.inputs:
						if (n.name == i.frommodule):	#jonkun saavutettavan moduulin input tulee t�lt� moduulilta
							if (not (n.isInSet(reachablemodules))):
								reachablemodules.append(n)
								newmodulesadded = 1
			if (newmodulesadded == 1):
				newmodulesadded = 0
			else:
				break
		## palautetaan reachable \ basemodules
		newreachable = []
		for r in reachablemodules:
			if (not (r.isInSet(basemodules))):
				newreachable.append(r)
		return newreachable
	
	def readAigerWitness(self, lines, tracefile):
		trace = Trace(tracefile)	# trace-instanssi johon talletetaan
		trace.storetrace(lines)
		stateclause = []	# nykyisess� tilassa voimassa olevat muuttujien arvot
		# ensimm�isell� rivill� pit�isi olla numero, toisella rivill� lista justice muuttujia, kolmannella rivill� init-arvot latcheille
		# viimeisell� rivill� on . 
		# pit�isi siis olla v�hint��n 5 rivi�, koska tracessa pit�� olla yksi tila
		#print len(lines)
		if len(lines) < 5:
			print "Aiger trace file too short"
		
		for i in range(3, ( len(lines) - 1)):
			#print "i", i
			#print "line", lines[i]
			stateclause.append(lines[i])
			trace.addNewState(stateclause)
			stateclause = []
		#print "tracelength", trace.getLength()
		return trace

	# luetaan XML-muotoinen trace tiedostosta ja
	# palautetaan Trace-instanssi johon se on luettu
	def readModelCheckingResult(self, tracefile):
		tf = open(tracefile)
		tulosterivit = tf.readlines()
		tf.close()
		if tulosterivit[0].strip() == '1':	# Aiger-trace files begin with a number on the first line. In this case it should be 1.
			print "Aiger witness detected"
			self.tracetype = 'aiger'
			return self.readAigerWitness(tulosterivit, tracefile)

		self.tracetype = ''
		trace = Trace(tracefile)	# trace-instanssi johon talletetaan
		trace.storetrace(tulosterivit)
		statenumber = 0	# miss� suorituksen (tuloste.txt) tilassa ollaan
		stateclause = []	# nykyisess� tilassa voimassa olevat muuttujien arvot
		#loopnumber = -1	# mihin tilaan looppi tulee polun viimeisest� tilasta


		for i in range(len(tulosterivit)):
			tulosterivit[i] = tulosterivit[i].strip()	#poistetaan whitespacea

			if tulosterivit[i].startswith('<?xml'):	# tuloste.txt ensimm�inen rivi on turha
				continue
			if tulosterivit[i].startswith('<counter-example'):	# ei toimenpiteit�
				continue
			if tulosterivit[i].startswith('<node'):	# ei toimenpiteit�
				continue
			if tulosterivit[i].startswith('<state'):	# uusi tila:
				statenumber = statenumber + 1
				if statenumber > 1:
					trace.addNewState(stateclause)
				stateclause = []			# nollataan t�m� muuttuja koska ollaan uudessa tilassa
				continue
			if tulosterivit[i].startswith('</state'):	# ei toimenpiteit�
				continue
			if tulosterivit[i].startswith('</node'):	# ei toimenpiteit�
				continue
			if tulosterivit[i].startswith('<loops>'):	# ei toimenpiteit�
				# tarvitaanko jotain toimenpiteit� t�h�n?
				# jos on invar-vastaesimerkki, niin ei kai ( ei looppeja safety-ehdolle)
				continue
			if tulosterivit[i].startswith('</loops>'):	# ei toimenpiteit�
				continue
			if tulosterivit[i].startswith('</counter-example>'):	# ei toimenpiteit�
				continue
			# else: variable assignment, kaikki muut rivit
			# muuttujan nimi on tagien =" ja "> v�liss�
			# muuttujan arvo on tagien "> ja </ v�liss�
			tag1 = tulosterivit[i].find('="') + 2	# mist� muuttujannimi alkaa
			tag2 = tulosterivit[i].find('">')		# mihin muuttujannimi loppuu
			tag3 = tulosterivit[i].find('">') + 2	# mist� muuttujan arvo alkaa
			tag4 = tulosterivit[i].find('</')	 	# mihin muuttujan arvo loppuu

			rivinmuuttuja = tulosterivit[i][tag1: tag2]
			rivinarvo = tulosterivit[i][tag3: tag4]


			a = Assignment(rivinmuuttuja, rivinarvo)
			stateclause.append(a)
						
		trace.addNewState(stateclause)	# viimeisen tilan muuttujien arvot pit�� lis�t� path-muuttujaan koska muuten ne j�isiv�t lis��m�tt� loopissa
		return trace


	# luetaan spesifikaatio ja palautetaan siin� olevat muuttujat
	def parseSpecificationVariables(self):
		ehto = self.specification
		# poistetaan kaikki operaattorit ym
		ehto = ' ' + ehto
		ehto = ehto.replace(' INVARSPEC ', '  ')
		ehto = ehto.replace(';', '')

		ehto = ehto.replace(' AG ', '  ')
		ehto = ehto.replace(' EG ', '  ')
		ehto = ehto.replace(' AF ', '  ')
		ehto = ehto.replace(' EF ', '  ')
		ehto = ehto.replace(' AX ', '  ')
		ehto = ehto.replace(' EX ', '  ')
		ehto = ehto.replace(' [ ', '  ')
		ehto = ehto.replace(' ] ', '  ')
		ehto = ehto.replace(' A ', '  ')
		ehto = ehto.replace(' E ', '  ')

		ehto = ehto.replace(' X ', '  ')
		ehto = ehto.replace(' F ', '  ')
		ehto = ehto.replace(' G ', '  ')
		ehto = ehto.replace(' U ', '  ')
		ehto = ehto.replace(' V ', '  ')

		# poistetaan perusoperaattorit
		ehto = re.sub(r'\(', '', ehto)
		ehto = re.sub(r'\)', '', ehto)
		ehto = re.sub(r'\=', '', ehto)
		ehto = re.sub(r'\->', '', ehto)
		ehto = re.sub(r'\<->', '', ehto)
		ehto = re.sub(r'\<', '', ehto)
		ehto = re.sub(r'\>', '', ehto)
		ehto = re.sub(r'\&', '', ehto)
		ehto = re.sub(r'\|', '', ehto)
		ehto = re.sub(r'\!', '', ehto)

		# poistetaan whitespace my�s < > <= >= ymp�rilt�
		ehto.strip()
		ehto = ehto.split()
		return ehto #palautetaan muuttujat taulukkona


	def printConfiguration(self):
		##print "Non-abstracted modules:"
		names = []
		for m in self.currentconfiguration:
			names.append(m.name)
		names.sort()
		for n in names:
			print "\tModule ", n


##################
### Funktion m��rittelyt:
##################
# Ajaa joukon testej�
# testit pit�� olla specfile-tiedostossa 1/rivi
# esim. INVARSPEC ();


# Run a set of specs: input given as a list of specifications
def testRunner(specs):
	#print "TestRunner!"
	#specsfile = open(specfile, 'r')
	#specs = [l.strip() for l in specsfile.readlines()]
	for specnro in range(0, len(specs)):
		print "Specification number: ", specnro +1
		algorithmRunner(specs[specnro], (specnro+1))

# Run a single spec
def algorithmRunner(specification, lognro):
	logfile = os.path.join(logdir, 'general_log.txt')

	algorithmstart = time.time()
	print "Reading model data..."
	modeldata = ModelStructure(specification)		# create the data structure of the model
	
	#for m in modeldata.modules:
	#	m.printModule()
	

	print "Model data read."
	### Begin the algorithm
	# Step 1 of the algorithm:
	print "Creating initial configuration of the model based on the specification..."
	modeldata.initializeConfiguration()
	if (modeldata.logmode):
		modeldata.stats.addToPropertyVerificationLog(modeldata.specification)
		modeldata.stats.addToPropertyVerificationLog("Initial Configuration:")
		for m in modeldata.currentconfiguration:
			modeldata.stats.addToPropertyVerificationLog(m.name)
	print "Initial configuration ready."
	# The main loop of the algorithm
	print "Launching main loop of the algorithm."
	valid_chars = "-_.() %s%s" % (string.ascii_letters, string.digits)
	dirspec = modeldata.specification.replace('|', 'or')
	dirspec = dirspec.replace('&', 'and')
	dirspec = dirspec.replace('!', 'not')
	dirspec = dirspec.replace('->', 'imply')

	dirspec = ''.join(c for c in dirspec if c in valid_chars)
	dirspec = dirspec.replace(' ', '')
	dirspec = "SPEC"+str(lognro)
	newdir = os.path.join(logdir, dirspec)

	#os.makedirs(logdir+ "/"+dirspec)
	if (modeldata.logmode):
		os.makedirs(newdir)
		os.chmod(newdir, 0o755)

	logfile2 =os.path.join(newdir, 'verification_procedure.txt')
	booleanresult = mainLoop(modeldata, newdir)
	### End of the algorithm

	print "The result of the algorithm is that the specification is ", booleanresult
	algorithmend = time.time()
	elapsed = (algorithmend - algorithmstart)
	print "Total elapsed time:", elapsed
	modeldata.stats.printStats()
	#modeldata.stats.addRunParameters("Delta", "")
	modeldata.stats.addResult(booleanresult, elapsed, modeldata.iteration, modeldata.currentconfiguration)
	modeldata.stats.printStatisticsLog(logfile)
	if(modeldata.logmode):
		modeldata.stats.printPropertyVerificationLog(logfile2)
	return booleanresult


#### Algoritmi:
# 1.	Choose the initial configuration of modules based on the invariant property
# Main Loop:
# 2.	Model check this configuration
# 3.	If the property is true return �true�. Else a counter-example is given.
# 4.	Based on the counter-example, refine the module configuration
# 5. 	Minimize the refinement
# 6.	Go to step 2.
####
def mainLoop(modeldata, logdir):
	# Step 2 of the algorithm:
	print "The current configuration of modules is:"
	modeldata.printConfiguration()
	if (modeldata.logmode):
		modeldata.stats.addToPropertyVerificationLog(modeldata.specification)
		modeldata.stats.addToPropertyVerificationLog("Configuration for iteration:" + str(modeldata.iteration +1))
		for m in modeldata.currentconfiguration:
			modeldata.stats.addToPropertyVerificationLog(m.name)
	print "Checking the specification (", modeldata.specification ,") on the current configuration of modules..."
	start = time.time()
	result, counterexample = modeldata.modelCheckCurrentConfiguration(logdir)
	elapsed = (time.time() - start)
	modeldata.stats.newModelCheckingTime(elapsed)

	print "This is iteration ", modeldata.iteration
	print "Model checking done."

	# Step 3 of the algorithm:
	if (result == "true"):
		print "The specification '", modeldata.specification ,"' was true!"
		if (modeldata.logmode):
			modeldata.stats.addToPropertyVerificationLog("Result true")
		return "true"
	else:
		print "The specification '", modeldata.specification ,"' was false on the abstracted model."
		if (modeldata.logmode):
			modeldata.stats.addToPropertyVerificationLog("Result false")
		## print "The counter-example was:"
		## counterexample.printTrace()
		minimizedcounterexample = counterexample
		print "Assuming that the counter-example is spurious.\nRefining the configuration."

		# Steps 4 and 5 of the algorithm
		refinementresult = modeldata.refineConfiguration(minimizedcounterexample, logdir)
		if (refinementresult == "no refinement"):
			print "The property could not be proved."
			if (modeldata.logmode):
				modeldata.stats.addToPropertyVerificationLog("Refinement over. No further refinement possible.")
			return "false"
		if (refinementresult == "proof"):
			print "The specification '", modeldata.specification ,"' was true!"
			if (modeldata.logmode):
				modeldata.stats.addToPropertyVerificationLog("Refinement found proof.")
			return "true"
		print "Suitable abstraction refinement found. Retrying model checking on the new abstraction."
		if (modeldata.logmode):
			modeldata.stats.addToPropertyVerificationLog("Refinement successful.")
		# Step 6 of the algorithm
		return mainLoop(modeldata,  logdir)

		print "ERROR: The feasibility of the counter-example could not be determined. Feasibility value was ", feasibility
	print "Unexpectedly reached end of the mainLoop function"
	sys.exit(1)

def dumpModel():
	ms = ModelStructure(args.spec)
	ms.currentconfiguration = ms.modules
	ms.generateModel()
	shutil.copyfile(ms.tempname, "dumped_model.smv")


def translateCE(witness, aiger_model, flat_smv, output):
	def read_symbols_from_aig(aig_lines):
		input_symbols = []
		latch_symbols = []

		input_i = 0
		latch_i = 0

		symbol_re = re.compile(r'.*([il])([0-9]+) ([0-9a-zA-Z!#$%&()*+,\-.:;<=>?@\[\]^_{|}~]+)$')

		for line in aig_lines:
			match = symbol_re.match(line)

			if not match:
				continue

			symbol_type = match.group(1)
			num = int(match.group(2))
			symbol = match.group(3)

			if symbol_type == 'l':
				if num != latch_i:
					sys.exit("Latch lines not in order")

				latch_symbols.append(symbol)
				latch_i += 1

			else:
				if num != input_i:
					sys.exit("Input lines not in order")

				input_symbols.append(symbol.replace('AIGER_NEXT_', ''))
				input_i += 1

		return input_symbols, latch_symbols

	def witness_line_to_state(line, aig_symbols):
		line = line.strip()
		state = dict()
		for i in range(0, len(line)):
			symbol = aig_symbols[i]
			value = True if line[i] == '1' else False
			state[symbol] = value
		return state

	def decode_state(state, definitions):
		decoded_state = dict(state)

		variables_to_decode = set()
		for symbol in state.iterkeys():
			symbol_bit_pair = symbol.rsplit('.', 1)
			if len(symbol_bit_pair) == 2 and symbol_bit_pair[1].isdigit():
				variables_to_decode.add(symbol_bit_pair[0])
				del decoded_state[symbol]

		for var in variables_to_decode:
			if var in definitions:
				value = definitions[var].eval(state)
				decoded_state[var] = value
			else:
				print "Warning, no definition for %s found!" % var
				decoded_state[var] = 0

		return decoded_state

	def state_to_xml(state, state_id):
		state = state.items()

		# # Sort variables using natural sorting (e.g. foo9 comes before foo10)
		# state = sorted(state, key=lambda p:
		# 	[int(text) if text.isdigit() else text
		# 	 for text in re.split(r'([0-9]+)', p[0])])

		xml_lines = []
		xml_lines.append('\t<node>')
		xml_lines.append('\t\t<state id="%d">' % state_id)

		for symbol, value in state:
			if isinstance(value, bool):
				value = 'TRUE' if value else 'FALSE'
			xml_line = '\t\t\t<value variable="%s">%s</value>' % (symbol, value)
			xml_lines.append(xml_line)

		xml_lines.append('\t\t</state>')
		xml_lines.append('\t</node>')
		return xml_lines


	# Open aiger model and read symbol names
	f = open(aiger_model)
	aig_lines = f.readlines()
	f.close()
	input_line_symbols, latch_line_symbols = read_symbols_from_aig(aig_lines)

	# Open flattened smv-file and parse how definitions are decoded
	f = open(flat_smv)
	smv_model = f.read()
	f.close()
	definitions = decode_smv_definitions.Parser().parse_file(smv_model)

	# Open witness file as array of lines
	f = open(witness)
	witness_lines = f.readlines()
	f.close()
	if len(witness_lines) < 5:
		print "Witness file too short!"
		sys.exit(1)


	CElines = []
	CElines.append('<?xml version="1.0" encoding="UTF-8"?>')
	CElines.append('<counter-example type="0" desc="LTL Counterexample" >')

	init_state = witness_line_to_state(witness_lines[2], latch_line_symbols)

	state_id = 1
	for i in range(3, len(witness_lines)-1):
		current_state = witness_line_to_state(witness_lines[i], input_line_symbols)

		# Merge the current state with init state so that variables with
		# inputs and latches are decoded correctly
		merged_state = dict(init_state)
		merged_state.update(current_state)
		current_state = merged_state

		current_state = decode_state(current_state, definitions)
		CElines.extend(state_to_xml(current_state, state_id))
		state_id += 1

	# Find out loopstate by checking which state is identical to the last one
	for i in range(3, len(witness_lines)-2):
		if witness_lines[-2] == witness_lines[i]:
			loopstate = i - 2
			CElines.append('<loops> %d </loops>' % loopstate)
			break

	CElines.append('</counter-example>')

	f = open(output, 'w')
	for l in CElines:
		print >> f, l
	f.close()


#### VARSINAINEN SUORITUS ALKAA: #########################
### Ohjelman parametrien lukeminen

if __name__ == '__main__':
	if sys.platform.startswith("win"):
		# Don't display the Windows GPF dialog if the invoked program dies.
		SEM_NOGPFAULTERRORBOX = 0x0002 # From MSDN
		ctypes.windll.kernel32.SetErrorMode(SEM_NOGPFAULTERRORBOX);
		subprocess_flags = 0x8000000
	else:
		subprocess_flags = 0

	argparser = argparse.ArgumentParser()
	argparser.add_argument('--logname')
	argparser.add_argument('--specfile')
	argparser.add_argument('--spec')
	argparser.add_argument('--algorithms')
	argparser.add_argument('--livenessalgorithms')
	argparser.add_argument('--dumpmodel', action='store_true')
	argparser.add_argument('model_main_file')
	args = argparser.parse_args()

	logdir = args.logname or datetime.datetime.now().strftime('log_%d.%m.%Y@%Hh%Mm%Ss')
	algo_dir = args.algorithms or "algorithms"
	liveness_dir = args.livenessalgorithms or "liveness-algorithms"

	# specfile-parametria tulee k�ytt��, jos halutaan testata monta ehtoa kerralla
	# ehdot tulee olla tiedostossa per�kk�in eri riveill�
	# jos t�t� parametria ei ole m��ritetty, tarkastetaan --spec parametrin m��ritt�m� ehto
	# jos t�m�kin on None, luetaan mallitiedostossa olevat ehdot

	specifications = []	# lista ehtoja jotka tarkastetaan mallilla
	if (args.dumpmodel):
		dumpModel()
	else:
		os.makedirs(logdir)
		os.chmod(logdir, 0o755)
		if (args.specfile == None):	# Jos ei ole m��ritelty specfilea
			if (args.spec == None):	# eik� --spec parametria:
				#  luetaan mallista speksit ja k�ytet��n niit�
				try:	# avataan mallitiedosto (main-file)
					inputfile = open(args.model_main_file)
					lines = inputfile.readlines()
					inputfile.close()
				except IOError:
					print "Could not read model data file (reading specifications)"
					sys.exit(1)
				#speccont = ""		# Ei tehd�k��n n�in: jos speksi jatkuu usealle riville niin tallennetaan aiemmat rivit t�h�n
				# vaan oletetaan ett� jokainen ehto on omalla rivill��n 
				for l in lines:		
					strip_l = l.strip()
					if ((strip_l.startswith('INVARSPEC')) | (strip_l.startswith('LTLSPEC'))): # Jos rivill� m��ritell��n invariantti tai LTL-speksi:
						specifications.append(strip_l)
					#
					#	if strip_l.endswith(';'): # speksi ei jatku seuraavalla rivill�
					#		specifications.append(strip_l)	# lis�t��n ehtojen listaan
					#		# print "Read Spec: ", strip_l
					#	else: #speksi jatkuu seuraavilla riveill�
					#		speccont = strip_l	#pistet��n ehdon alkup�� talteen
					#	continue
					#if (speccont != ""): 	# jos edellisill� riveill� on aloitettu jotain ehtoa
					#	if strip_l.endswith(';'): # ehto p��ttyy t�lle riville
					#		speccont = speccont + " " + strip_l  # otetaan alkup�� mukaan
					#		specifications.append(speccont)		# lis�t��n ehtojen listaan
					#		#print "Read Spec: ", speccont
					#		speccont = ""					# tyhjennet��n 
					#		continue
					#	else: # ehto jatkuu viel�kin
					#		speccont = speccont + " " + strip_l
					#		continue
			else:
				specifications.append(args.spec)
		else:
			## lue tiedostosta speksit listaan ja aja testRunner
			specsfile = open(args.specfile, 'r')
			specifications = [l.strip() for l in specsfile.readlines()]
			specsfile.close()
			
		# lopuksi ajetaan speksit:
		if (len(specifications)>0):
			testRunner(specifications)
		else:
			print "No specifications found!"

