#!/usr/bin/env zsh
exec NuSMV -dynamic -int -coi $1 <<EOF
set on_failure_script_quits
go
check_ltlspec
show_traces -p 4 -o bddLTL_trace.txt
quit
EOF
