#!/usr/bin/env zsh
set -e
grep -F LTLSPEC $1 | sed 's/LTLSPEC//' > $$.ltl
cat $1 | grep -v -F LTLSPEC > $$.smv
${0:h}/../l2s4lmcs_Revised/bin/convert.bash -nusmv -l2sbmc -notight -optnone $$ $$
exec NuSMV -dynamic -int -coi $$.$$.l2sbmc.notight.none.nusmv <<EOF
set on_failure_script_quits
go
check_invar
show_traces -p 4 -o bdd_trace.txt
quit
EOF
