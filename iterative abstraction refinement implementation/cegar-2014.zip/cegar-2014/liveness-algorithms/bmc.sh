#!/usr/bin/env zsh
set -e
if [[ $# -gt 1 ]]; then
	k=$2
else
	k=100000
fi
grep -F LTLSPEC $1 | sed 's/LTLSPEC//' > $$.ltl
cat $1 | grep -v -F LTLSPEC > $$.smv
${0:h}/../l2s4lmcs_Revised/bin/convert.bash -nusmv -l2sbmc -notight -optnone $$ $$
exec NuSMV -int -coi $$.$$.l2sbmc.notight.none.nusmv <<EOF
set on_failure_script_quits
go_bmc
check_invar_bmc_inc -k $k
show_traces -p 4 -o bmc_trace.txt 1
quit
EOF
