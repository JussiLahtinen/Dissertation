#!/usr/bin/env zsh
python ../smv2aig.py --nusmv -o abczz.aig $1
exec bip ,live -k=inc -eng=pdr2 -wit=abczz_trace.txt -input=abczz.aig

