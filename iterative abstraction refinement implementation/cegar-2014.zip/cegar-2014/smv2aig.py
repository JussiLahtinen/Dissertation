#!/usr/bin/env python
from argparse import ArgumentParser
from tempfile import NamedTemporaryFile
from subprocess import check_call, Popen, PIPE, CalledProcessError
from os.path import splitext
from os import remove, environ

arser = ArgumentParser(description='Convert an SMV file to an AIG file.')
arser.add_argument('smv_file')
arser.add_argument('--nusmv', help='Use NuSMV for flattening; the NuSMV executable is located via the NUSMV environment variable if defined', action='store_true')
arser.add_argument('-o', help='Output file', metavar='aigfile')
args = arser.parse_args()

nusmv = environ['NUSMV'] if environ.has_key('NUSMV') else 'NuSMV'

flat_f = NamedTemporaryFile(suffix='.smv', delete=False)
if args.nusmv:
    flat_f.close()

    # Flattening is done twice because the second round gets rid of
    # definitions that smvtoaig cannot read. Definitions are needed
    # for building counter examples so the first output file is saved too.
    for in_f, out_f in [(args.smv_file, 'flat-orig.smv'),
                        ('flat-orig.smv', flat_f.name)]:
        cmd = [nusmv, '-int', in_f]
        p = Popen(cmd, stdin=PIPE)
        p.communicate("""
            set on_failure_script_quits
            read_model
            flatten_hierarchy
            encode_variables
            build_boolean_model
            write_boolean_model -o {0}
            quit
            """.format(out_f))
        if p.returncode != 0:
            raise CalledProcessError(p.returncode, cmd)
else:
    check_call(['smvflatten', '-mangle', args.smv_file], stdout=flat_f)
    flat_f.close()

check_call(['smvtoaig', flat_f.name, args.o or splitext(args.smv_file)[0] + '.aig'])
remove(flat_f.name)
