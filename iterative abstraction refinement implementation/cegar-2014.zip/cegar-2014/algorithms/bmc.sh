#!/usr/bin/env zsh
set -e
if [[ $# -gt 1 ]]; then
	k=$2
else
	k=100000
fi
exec NuSMV -int -coi $1 <<EOF
set on_failure_script_quits
go_bmc
check_invar_bmc_inc -k $k
show_traces -p 4 -o bmc_trace.txt 1
quit
EOF
