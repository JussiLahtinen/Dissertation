#!/usr/bin/env zsh
set -e
exec NuSMV -dynamic -int -coi $@ <<EOF
set on_failure_script_quits
go
check_invar
show_traces -p 4 -o bdd_trace.txt
quit
EOF
