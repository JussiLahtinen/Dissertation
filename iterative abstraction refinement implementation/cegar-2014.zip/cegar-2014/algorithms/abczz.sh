#!/usr/bin/env zsh
rm LTLmodel.smv
sed 's/INVARSPEC/LTLSPEC G/g' $1 > LTLmodel.smv
python ../smv2aig.py --nusmv -o abczz.aig LTLmodel.smv
exec bip ,live -k=inc -eng=pdr2 -wit=abczz_trace.txt -input=abczz.aig

