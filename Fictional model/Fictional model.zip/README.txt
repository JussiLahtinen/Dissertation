This folder contains documents related to a fictional model used in the RESS 2015 paper (Publication III).

"Full model.smv" contains the full system model including the behaviour of all modules'.

Other model files are divided into parts so that the iterative abstraction refinement technique can be used by 
giving the "main.smv" module file as parameter.
	-main.smv creates instances of the modules. This is the main file of the model.
	-FBs.smv includes the function block models used in this system
	-modulex.smv contains the model for Module x (replace x with number)
	-modulex_interface.smv contains an interface version of Module x

"Model description.pdf" includes a function block description of each module, and a short description of the purpose
of the module.